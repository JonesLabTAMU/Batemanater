//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveExecute(TObject *Sender)
{
  if (SaveDialog1->Execute())
   {
     RichEdit1->Lines->SaveToFile(SaveDialog1->FileName);
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::GenRandsExecute(TObject *Sender)
{
   int i;
   double Arandnum;
   double Brandnum;
   AnsiString tempString;

   Form4->Show();
   Form4->Repaint();
   TMyThread *SecondThread = new TMyThread(true);
   SecondThread->Priority = tpTimeCritical;
   SecondThread->Resume();
   Form4->ProgressBar1->Max = 10000;
   Form4->ProgressBar1->Position = 0;

    for (i = 0; i < 10000; i++)
    {
       randbivnorm(1, 1, 0.5);
       Arandnum = bivN1;
       Brandnum = bivN2;
       tempString = FloatToStrF(Arandnum,ffFixed,6,6) + "\t";
       tempString = tempString + FloatToStrF(Brandnum,ffFixed,6,6);
	   RichEdit1->Lines->Add(tempString);
	   Form4->ProgressBar1->Position++;
	   Form4->Repaint();
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{

   // Seed the random number generator.

    int seedrnum;

    Randomize();
    randomize();

    seedrnum = rand() + 1;

	sgenrand(seedrnum);

  // Arrays on the heap should be created here using the new operator.
  // They should be deleted in the FormDestroy subroutine.

   globalMaleRS = new double[5000];
   globalMaleMS = new double[5000];

   globalFemaleMeanMS = 1.785;
   globalFemaleMeanRS = 330.5;
   globalSexRatio = 0.516;
   globalEstimatedNumberMales = 74;
   globalClutchesSampled = 50;
   globalNmsIntervals = 10;
   globalNrsIntervals = 25;
   globalEstReps = 250;
   globalBootReps = 200;
   globalEstimationSDMS = 2.6;
   globalMSstddevmax = 3;
   globalRSstddevmax = 3;
   globalNmsintervals = 200;
   globalRSperMatemax = 1.2;
   globalRSperMSintervals = 20;
   globalMSestreps = 5000;
   globalcorrMSRS = 120;
   globalSigmaRS = 250;

   globalNmaleData = 31;
   globalMaleMS[0]  = 1; globalMaleRS[0]  = 390;
   globalMaleMS[1]  = 1; globalMaleRS[1]  = 286;
   globalMaleMS[2]  = 1; globalMaleRS[2]  = 263;
   globalMaleMS[3]  = 1; globalMaleRS[3]  = 290;
   globalMaleMS[4]  = 1; globalMaleRS[4]  = 183;
   globalMaleMS[5]  = 1; globalMaleRS[5]  = 246;
   globalMaleMS[6]  = 1; globalMaleRS[6]  = 104;
   globalMaleMS[7]  = 1; globalMaleRS[7]  = 369;
   globalMaleMS[8]  = 1; globalMaleRS[8]  = 114;
   globalMaleMS[9]  = 1; globalMaleRS[9]  = 251;
   globalMaleMS[10] = 1; globalMaleRS[10] = 230;
   globalMaleMS[11] = 1; globalMaleRS[11] = 262;
   globalMaleMS[12] = 1; globalMaleRS[12] = 172;
   globalMaleMS[13] = 1; globalMaleRS[13] = 192;
   globalMaleMS[14] = 1; globalMaleRS[14] = 124;
   globalMaleMS[15] = 1; globalMaleRS[15] = 47;
   globalMaleMS[16] = 1; globalMaleRS[16] = 367;
   globalMaleMS[17] = 1; globalMaleRS[17] = 143;
   globalMaleMS[18] = 1; globalMaleRS[18] = 8;
   globalMaleMS[19] = 2; globalMaleRS[19] = 370;
   globalMaleMS[20] = 2; globalMaleRS[20] = 590;
   globalMaleMS[21] = 2; globalMaleRS[21] = 274;
   globalMaleMS[22] = 2; globalMaleRS[22] = 299;
   globalMaleMS[23] = 2; globalMaleRS[23] = 244;
   globalMaleMS[24] = 2; globalMaleRS[24] = 361;
   globalMaleMS[25] = 3; globalMaleRS[25] = 680;
   globalMaleMS[26] = 3; globalMaleRS[26] = 576;
   globalMaleMS[27] = 3; globalMaleRS[27] = 425;
   globalMaleMS[28] = 3; globalMaleRS[28] = 338;
   globalMaleMS[29] = 3; globalMaleRS[29] = 348;
   globalMaleMS[30] = 4; globalMaleRS[30] = 835;

   globalmeanMS = 5;
   globalstddevMS = 2;

   globalmeanRSsim = 500;
   globalSDwithinMSclass = 100;
   globalincreaseRSperMate = 0;

   globalNmales = 150;

   globalpropClutchesSampled = 0.20;

   globalBigRun = false;

   LogFileName = "NoFile";
   StatusBar1->SimpleText = "No Log File Selected";


}
//---------------------------------------------------------------------------

void __fastcall TForm1::MainExecute(TObject *Sender)
{
		DisableUI->Execute();

		MSG winmsg;
        int i, j, k, l, m, n, o, reps;

        int Nmales, Nclutches;
        double MeanMS;
        double MeanRS;
        double SigmaMS;
        double SigmaRS;
        double corrMSRS;
        AnsiString Tstr;
        double tempMS, tempRS, remainder;
        int rndi;
        int NclutchesSampled;
        double DataStDevMS, DataStDevRS, DataBatemanGradient;
        int Ntrunc;
        double dub1, dub2;
        double sampleStdDevMS, sampleStdDevRS, sampleBatemanGradient;
        int Nsinglematers;
        double sampleMeanMS, sampleMeanRS, sampleCov;
        double realMeanMS, realMeanRS, realStdDevMS, realStdDevRS, realBG, realCov, realI, realIs;
        double chiSqr;
        double sAveMSmean, sAveRSmean, sSDmsmean, sSDrsmean, sBGmean, rAveMSmean,
               rAveRSmean, rSDmsmean, rSDrsmean, rBGmean, ChiSqrmean;
        int totalreps;
        double LowestChiSquare, EstMeanMS, EstMeanRS, EstStdDevMS, EstStdDevRS, EstBatemanGradient, EstBGnz;
        double OppSel, OppSexSel;
        int NmaleDataInt, dataNsinglematers;
        double dataMeanMS, dataMeanRS, dataVarMS, dataCov;
        int iNmsIntervals, iNrsIntervals;
        double sizeMSinter, sizeRSinter;
        double tempMeanMS, tempMeanRS;
        int dataNdoublematers, dataNtriplematers, dataNquadmaters;
        int Ndoublematers, Ntriplematers, Nquadmaters;
        double maxIncreaseRSperMating;
        double RSincreaseInterval;
        double Imean, Ismean;
        double realBGnozeros, rBGnzmean, tempSDms;
        int realNtrunc;
        int slopeincreaseintervals;
        double EstBGprime;
        double EstSmax;
        double realBGprime, realSmax;
        double rBGprimemean, rSmaxmean;


        int dataNwithMS[20];
        double dataMeanRSforMS[20];
        double dataStDevRSforMS[20];

        int sampleNwithMS[20];
        double sampleMeanRSforMS[20];
        double sampleStDevRSforMS[20];

        double meansampleMeanRSforMS[20];
        double meansampleStDevRSforMS[20];

        double toptenMS[10];
        double toptenRS[10];
        double toptenSDms[10];
        double toptenSDrs[10];
        double toptenBG[10];
        double toptenI[10];
        double toptenIs[10];
        double toptenChiSqr[10];
        double toptenBGnz[10];
        double toptencorrMSRS[10];
        double toptenSigmaRS[10];
        double toponecorrMSRS;
        double toponeSigmaRS;
        double toptenBGprime[10];
        double toptenSmax[10];

        bool usedMSmean[20];
        bool usedMSstdev[20];

        if (!globalBigRun)
         RichEdit1->Clear();

        NmaleDataInt = globalNmaleData;

        MeanMS = (globalFemaleMeanMS * (1 - globalSexRatio))/globalSexRatio;    // Mean is from the collected sex
        MeanRS = (globalFemaleMeanRS * (1 - globalSexRatio))/globalSexRatio;  // Mean is from the collected sex
        DataStDevMS = StdDev(globalMaleMS,NmaleDataInt-1);  // from the unknown sex
        DataStDevRS = StdDev(globalMaleRS,NmaleDataInt-1);  // from the unknown sex

        globalCalculatedMaleMSmean = MeanMS;
        globalCalculatedMaleRSmean = MeanRS;


        dataMeanMS = Mean(globalMaleMS,NmaleDataInt-1);
        dataMeanRS = Mean(globalMaleRS,NmaleDataInt-1);
        dataVarMS = Variance(globalMaleMS,NmaleDataInt-1);

        iNrsIntervals = globalNrsIntervals;
        sizeRSinter = (globalRSperMatemax*MeanRS)/globalNrsIntervals;
        maxIncreaseRSperMating = (MeanRS/MeanMS)*globalRSperMatemax;
        RSincreaseInterval = maxIncreaseRSperMating/globalRSperMSintervals;
        slopeincreaseintervals = globalRSperMSintervals * 2 + 1;

        dub1 = 0;
        dub2 = 0;

        for (i = 0; i < NmaleDataInt; i++)
        {
          dub1 = dub1 + (globalMaleMS[i] - dataMeanMS) * (globalMaleRS[i] - dataMeanRS);
          dub2 = dub2 + 1;
        }

        if (dub2 > 1)
          dataCov = dub1/(dub2-1);
        else
          dataCov = 0;

        if (dataVarMS > 0)
          DataBatemanGradient = dataCov/dataVarMS;
        else
          DataBatemanGradient = 0;

        SigmaMS = 0;
        SigmaRS = 0;
        totalreps = globalEstReps;
        Nmales = globalEstimatedNumberMales;           // Estimated total number of the uncollected sex
        NclutchesSampled = globalClutchesSampled; // Nclutches sampled from the data

        int *ClutchFather = new int[20000];
        int *ClutchSize = new int[20000];
        int *ClutchSampled = new int[20000];
        int *RealFatherMS = new int[Nmales];
        int *RealFatherRS = new int[Nmales];
        int *tempNinClutch = new int[500];
        int *sampleCF = new int[5000];
        int *sampleCS = new int[5000];
        int *ApparentFMS = new int[Nmales];
        int *ApparentFRS = new int[Nmales];
        double *truncAppFMS = new double[Nmales];
        double *truncAppFRS = new double[Nmales];
        double *realFMS = new double[Nmales];
        double *realFRS = new double[Nmales];
        double *realFMStrunc = new double[Nmales];
        double *realFRStrunc = new double[Nmales];

        double **RSfirstMSthenInd;
        RSfirstMSthenInd = new double*[20];
        for (i = 0; i < 20; i++)
           RSfirstMSthenInd[i] = new double[Nmales];

        for (i = 0; i < 20; i++)
        {
           dataNwithMS[i] = 0;
           for (j = 0; j < NmaleDataInt; j++)
           {
                RSfirstMSthenInd[i][j] = 0;
           } // end of j
        } // end of i

        for (i = 0; i < NmaleDataInt; i++)
        {
          if (globalMaleMS[i] < 20)
          {
            rndi = globalMaleMS[i];
            RSfirstMSthenInd[rndi][dataNwithMS[rndi]] = globalMaleRS[i];
            dataNwithMS[rndi]++;
          } // end of i
        }

        for (i = 1; i < 20; i++)
        {
           if (dataNwithMS[i] > 0)
              dataMeanRSforMS[i] = Mean(RSfirstMSthenInd[i],dataNwithMS[i]-1);
           else
              dataMeanRSforMS[i] = -1;

          if (dataNwithMS[i] > 1)
              dataStDevRSforMS[i] = StdDev(RSfirstMSthenInd[i],dataNwithMS[i]-1);
           else
              dataStDevRSforMS[i] = -1;
        } // end of i


        Tstr = "dAveMS\tdAveRS\tdSDms\tdSDrs\tdBG";
        Tstr = Tstr + "\tpSDms\tpSDrs\tpRSperM\tpNmale\tpNcltch\t";

        for (i = 1; i < 20; i++)
           Tstr = Tstr + "dAve" + IntToStr(i) + "m\tdSD" + IntToStr(i) + "m\t";

        for (i = 1; i < 20; i++)
           Tstr = Tstr + "sAve" + IntToStr(i) + "m\tsSD" + IntToStr(i) + "m\t";

        Tstr = Tstr + "sAveMS\tsAveRS\tsSDms\tsSDrs\tsBG\trAveMS\trAveRS\trSDms\trSDrs\trBG\trBGno0s\tBG'\tIs\tI\ts'max\tChiSqr";
        if (!globalBigRun)
           RichEdit1->Lines->Add(Tstr);

        LowestChiSquare = 1000000;
        for (i = 0; i < 10; i++)
           toptenChiSqr[i] = 1000000;

       // sigmaRS is the variance within a mating category
       // sigmaMS is the variance in mating success
       // corrMSRS is the increase in the number of offspring with each mating

          SigmaMS = globalEstimationSDMS;
		  SigmaRS = 0 - sizeRSinter;


       for (n = 0; n < iNrsIntervals + 1; n++)
       {
          SigmaRS = SigmaRS + sizeRSinter;                               // this is the standard deviation within each MS class
          corrMSRS = -1 * maxIncreaseRSperMating - RSincreaseInterval;   // this is the change in mean RS per mate

       for (o = 0; o < slopeincreaseintervals; o++)
	   {
          corrMSRS = corrMSRS + RSincreaseInterval;

          for (i = 0; i < 20; i++)
          {
            usedMSmean[i] = true;
            usedMSstdev[i] = true;
          }

          sAveMSmean = 0;
          sAveRSmean = 0;
          sSDmsmean = 0;
          sSDrsmean = 0;
          sBGmean = 0;
          rAveMSmean = 0;
          rAveRSmean = 0;
          rSDmsmean = 0;
          rSDrsmean = 0;
          rBGmean = 0;
          ChiSqrmean = 0;
          rBGnzmean = 0;
          rBGprimemean = 0;
          rSmaxmean = 0;

          Imean = 0;
          Ismean = 0;

          for (i = 0; i < 20; i++)
          {
            meansampleMeanRSforMS[i] = 0;
            meansampleStDevRSforMS[i] = 0;
          }

           Tstr = FloatToStrF(MeanMS,ffFixed,8,3) + "\t" + FloatToStrF(MeanRS,ffFixed,8,3) + "\t";
           Tstr = Tstr + FloatToStrF(DataStDevMS,ffFixed,8,3) + "\t" + FloatToStrF(DataStDevRS,ffFixed,8,3) + "\t";
           Tstr = Tstr + FloatToStrF(DataBatemanGradient,ffFixed,8,3) + "\t";
           Tstr = Tstr + FloatToStrF(SigmaMS,ffFixed,8,3) + "\t" + FloatToStrF(SigmaRS,ffFixed,8,3) + "\t";
           Tstr = Tstr + FloatToStrF(corrMSRS,ffFixed,8,3) + "\t" + IntToStr(Nmales) + "\t";
           Tstr = Tstr + IntToStr(NclutchesSampled) + "\t";

           for (i = 1; i < 20; i++)
           {
            if (dataMeanRSforMS[i] > 0)
             Tstr = Tstr + FloatToStrF(dataMeanRSforMS[i],ffFixed,8,2) + "\t";
            else
             Tstr = Tstr + "na\t";
            if (dataStDevRSforMS[i] > 0)
             Tstr = Tstr + FloatToStrF(dataStDevRSforMS[i],ffFixed,8,2) + "\t";
            else
             Tstr = Tstr + "na\t";
		   }



       for (reps = 0; reps < totalreps; reps++)
	   {
		   Nclutches = 0;

        tempMeanMS = 0;
        while (tempMeanMS == 0)
        {
        // Assign male MS
          for (i = 0; i < Nmales; i++)
          {
             realFMS[i] = randnorm(MeanMS,SigmaMS);
             if (realFMS[i] < 0)
                realFMS[i] = 0;
          } // end of i
          tempMeanMS = Mean(realFMS,Nmales-1);
        } // end of while -- don't let the meanMS be 0

        for (i = 0; i < Nmales; i++)  // scale and round MS
        {
           realFMS[i] = realFMS[i] * (MeanMS/tempMeanMS);
           remainder = realFMS[i] - floor(realFMS[i]);
           if (remainder >= 0.5)
              realFMS[i] = floor(realFMS[i]) + 1;
           else
              realFMS[i] = floor(realFMS[i]);
        }

        //assign reproductive success
        tempMeanRS = 0;
        while (tempMeanRS == 0)
        {
          for (i = 0; i < Nmales; i++)
          {
             realFRS[i] = randnorm(MeanRS,SigmaRS) + ((realFMS[i]-MeanMS) * corrMSRS);
             if (realFRS[i] < realFMS[i])
                realFRS[i] = realFMS[i];  // you have to have at least 1 offspring per mating and negative values are not allowed
             if (realFMS[i] == 0)   // no MS = no RS
                realFRS[i] = 0;
          } // end of i
          tempMeanRS = Mean(realFRS,Nmales-1);
        } // end of while

        // round and adjust RS values

        for (i = 0; i < Nmales; i++)
        {
           realFRS[i] = realFRS[i] * (MeanRS/tempMeanRS);
           remainder = realFRS[i] - floor(realFRS[i]);
           if (remainder >= 0.5)
              realFRS[i] = floor(realFRS[i]) + 1;
           else
              realFRS[i] = floor(realFRS[i]);

           if (realFRS[i] < realFMS[i])
              realFRS[i] = realFMS[i];

         } // end of i

        // assign clutch sizes

        for (i = 0; i < Nmales; i++)
        {
           tempMS = realFMS[i];
           tempRS = realFRS[i];

           RealFatherMS[i] = tempMS;
           RealFatherRS[i] = tempRS;

           if (RealFatherMS[i] > 0)
           {
            dub2 = 0;
            dub1 = tempRS/tempMS;
            dub1 = floor(dub1);
            for (j = 0; j < RealFatherMS[i]; j++)
            {
              tempNinClutch[j] = dub1;
              dub2 = dub2 + dub1;
            }

            dub1 = RealFatherRS[i];
            tempNinClutch[0] = tempNinClutch[0] + (dub1 - dub2);

            for (j = 0; j < RealFatherMS[i]; j++)
            {
              ClutchFather[Nclutches] = i;
              ClutchSize[Nclutches] = tempNinClutch[j];
              Nclutches++;
            } // end of j
           } // end of if

        } // end of i

        // Now sample clutches

        for (i = 0; i < Nclutches; i++)
           ClutchSampled[i] = 0;

        if (NclutchesSampled > Nclutches)
           NclutchesSampled = Nclutches;

        for (i = 0; i < NclutchesSampled; i++)
        {
           rndi = randnum(Nclutches);
           while (ClutchSampled[rndi] == 1)
              rndi = randnum(Nclutches);
           sampleCF[i] = ClutchFather[rndi];
           sampleCS[i] = ClutchSize[rndi];
           ClutchSampled[rndi] = 1;

        } // end of i

        // calculate apparent RS and MS

        for (i = 0; i < Nmales; i++)
        {
           ApparentFMS[i] = 0;
           ApparentFRS[i] = 0;
        }

        for (i = 0; i < NclutchesSampled; i++)
        {
           j = sampleCF[i];
           ApparentFMS[j] = ApparentFMS[j] + 1;
           ApparentFRS[j] = ApparentFRS[j] + sampleCS[i];
        }

        Ntrunc = 0;

        for (i = 0; i < Nmales; i++)
        {
           if (ApparentFMS[i] > 0)
           {
              truncAppFMS[Ntrunc] = ApparentFMS[i];
              truncAppFRS[Ntrunc] = ApparentFRS[i];
              Ntrunc++;
           }
        } // end of i


        for (i = 0; i < 20; i++)
           sampleNwithMS[i] = 0;

        for (i = 0; i < Ntrunc; i++)
        {
          if (truncAppFMS[i] < 20)
          {
            j = truncAppFMS[i];
            k = sampleNwithMS[j];
            RSfirstMSthenInd[j][k] = truncAppFRS[i];
            sampleNwithMS[j]++;
          } // end of i
        }

        for (i = 1; i < 20; i++)
        {
           if (sampleNwithMS[i] > 0)
              sampleMeanRSforMS[i] = Mean(RSfirstMSthenInd[i],sampleNwithMS[i]-1);
           else
              sampleMeanRSforMS[i] = -1;

          if (sampleNwithMS[i] > 1)
              sampleStDevRSforMS[i] = StdDev(RSfirstMSthenInd[i],sampleNwithMS[i]-1);
           else
              sampleStDevRSforMS[i] = -1;
        } // end of i

         // Calculate Bateman Gradients and so on for the sample

       if (Ntrunc > 1)
       {
        sampleStdDevMS = StdDev(truncAppFMS,Ntrunc-1);
        sampleStdDevRS = StdDev(truncAppFRS,Ntrunc-1);
       }
       else
       {
        sampleStdDevMS = 0;
        sampleStdDevRS = 0;
       }

        sampleMeanMS = Mean(truncAppFMS,Ntrunc-1);
        sampleMeanRS = Mean(truncAppFRS,Ntrunc-1);

		dub1 = 0;
        for (i = 0; i < Ntrunc; i++)
          dub1 = dub1 + (truncAppFMS[i] - sampleMeanMS) * (truncAppFRS[i] - sampleMeanRS);
        dub2 = Ntrunc;

        sampleCov = dub1/(dub2 - 1);

        if (sampleStdDevMS > 0)
          sampleBatemanGradient = sampleCov/(sampleStdDevMS * sampleStdDevMS);
        else
          sampleBatemanGradient = 0;

        for (i = 0; i < Nmales; i++)
        {
          realFMS[i] = RealFatherMS[i];
          realFRS[i] = RealFatherRS[i];
        } // end of i

        realMeanMS = Mean(realFMS,Nmales-1);
        realMeanRS = Mean(realFRS,Nmales-1);
        realStdDevMS = StdDev(realFMS,Nmales-1);
        realStdDevRS = StdDev(realFRS,Nmales-1);
        realIs = (realStdDevMS*realStdDevMS)/(realMeanMS*realMeanMS);
        realI = (realStdDevRS*realStdDevRS)/(realMeanRS*realMeanRS);

        dub1 = 0;
        dub2 = Nmales;
        for (i = 0; i < Nmales; i++)
          dub1 = dub1 + (realFMS[i] - realMeanMS) * (realFRS[i] - realMeanRS);
        realCov = dub1/(dub2 - 1);

        if (realStdDevMS > 0)
          realBG = realCov/(realStdDevMS * realStdDevMS);
        else
          realBG = 0;

        if (realMeanMS/realMeanRS > 0)  {
            realBGprime = realBG*(realMeanMS/realMeanRS);
        }

        realSmax = realBGprime*sqrt(realIs);

        realNtrunc = 0;
        for (i = 0; i < Nmales; i++)
        {
           if (realFMS[i] > 0)
           {
              realFMStrunc[realNtrunc] = realFMS[i];
              realFRStrunc[realNtrunc] = realFRS[i];
              realNtrunc++;
           }
        } // end of i

        tempMeanMS = Mean(realFMStrunc,realNtrunc-1);
        tempMeanRS = Mean(realFRStrunc,realNtrunc-1);
        tempSDms = StdDev(realFMStrunc,realNtrunc-1);

        dub1 = 0;
        dub2 = realNtrunc;
        for (i = 0; i < realNtrunc; i++)
           dub1 = dub1 + (realFMStrunc[i] - tempMeanMS) * (realFRStrunc[i] - tempMeanRS);
        realBGnozeros = dub1/(dub2-1);

        if (tempSDms > 0)
          realBGnozeros = realBGnozeros/(tempSDms*tempSDms);
        else
          realBGnozeros = 0;

        // Calculate Chi-square

        chiSqr = 0;

        if (DataStDevRS > 0)
           chiSqr = chiSqr + (sampleStdDevRS - DataStDevRS)*(sampleStdDevRS - DataStDevRS)/DataStDevRS;

        if (DataBatemanGradient > 1)
           chiSqr = chiSqr + (sampleBatemanGradient - DataBatemanGradient)*(sampleBatemanGradient - DataBatemanGradient)/DataBatemanGradient;
        if (DataBatemanGradient < -1)
           chiSqr = chiSqr + (sampleBatemanGradient - DataBatemanGradient)*(sampleBatemanGradient - DataBatemanGradient)/(-1 * DataBatemanGradient);
        if (DataBatemanGradient >= -1 && DataBatemanGradient <=1)
           chiSqr = chiSqr + (sampleBatemanGradient - DataBatemanGradient)*(sampleBatemanGradient - DataBatemanGradient);

        dub2 = NmaleDataInt;
        for (i = 1; i < 20; i++)
        {
          dub1 = dataNwithMS[i];
          if (dub1 > 0)
          {
             if (dataMeanRSforMS[i] > 0 && sampleMeanRSforMS[i] > 0)
               chiSqr = chiSqr + (dub1/dub2) * (((sampleMeanRSforMS[i] - dataMeanRSforMS[i]) * (sampleMeanRSforMS[i] - dataMeanRSforMS[i]))/dataMeanRSforMS[i]);

             if (dataStDevRSforMS[i] > 0 && sampleStDevRSforMS[i] > 0)
               chiSqr = chiSqr + (dub1/dub2) * (((sampleStDevRSforMS[i] - dataStDevRSforMS[i]) * (sampleStDevRSforMS[i] - dataStDevRSforMS[i]))/dataStDevRSforMS[i]);
          }

          if (sampleMeanRSforMS[i] < 0)
               usedMSmean[i] = false;

          if (sampleStDevRSforMS[i] < 0)
               usedMSstdev[i] = false;

        } // end of i

        sAveMSmean = sAveMSmean + sampleMeanMS;
        sAveRSmean = sAveRSmean + sampleMeanRS;
        sSDmsmean = sSDmsmean + sampleStdDevMS;
        sSDrsmean = sSDrsmean + sampleStdDevRS;
        sBGmean = sBGmean + sampleBatemanGradient;
        rAveMSmean = rAveMSmean + realMeanMS;
        rAveRSmean = rAveRSmean + realMeanRS;
        rSDmsmean = rSDmsmean + realStdDevMS;
        rSDrsmean = rSDrsmean + realStdDevRS;
        rBGmean = rBGmean + realBG;
        rBGnzmean = rBGnzmean + realBGnozeros;
        ChiSqrmean = ChiSqrmean + chiSqr;
        Imean = Imean + realI;
        Ismean = Ismean + realIs;
        rBGprimemean = rBGprimemean + realBGprime;
        rSmaxmean = rSmaxmean + realSmax;

        for (i = 1; i < 20; i++)
        {
          meansampleMeanRSforMS[i] = meansampleMeanRSforMS[i] + sampleMeanRSforMS[i];
          meansampleStDevRSforMS[i] = meansampleStDevRSforMS[i] + sampleStDevRSforMS[i];
		}

		// Before the end of each rep, check to see if there are windows messages
		// and pass them to windows to handle them

		if (PeekMessage(&winmsg,NULL,0,0,PM_REMOVE)) {
			TranslateMessage(&winmsg);
			DispatchMessage(&winmsg);
        }

       } // end of reps

        dub2 = totalreps;
        sAveMSmean = sAveMSmean/dub2;
        sAveRSmean = sAveRSmean/dub2;
        sSDmsmean = sSDmsmean/dub2;
        sSDrsmean = sSDrsmean/dub2;
        sBGmean = sBGmean/dub2;
        rAveMSmean = rAveMSmean/dub2;
        rAveRSmean = rAveRSmean/dub2;
        rSDmsmean = rSDmsmean/dub2;
        rSDrsmean = rSDrsmean/dub2;
        rBGmean = rBGmean/dub2;
        ChiSqrmean = ChiSqrmean/dub2;
        Imean = Imean/dub2;
        Ismean = Ismean/dub2;
        rBGnzmean = rBGnzmean/dub2;
        rBGprimemean = rBGprimemean/dub2;
        rSmaxmean = rSmaxmean/dub2;

        for (i = 1; i < 20; i++)
        {
          meansampleMeanRSforMS[i] = meansampleMeanRSforMS[i]/dub2;
          meansampleStDevRSforMS[i] = meansampleStDevRSforMS[i]/dub2;
        }

        for (i = 1; i < 20; i++)
        {
            if (usedMSmean[i] == true)
             Tstr = Tstr + FloatToStrF(meansampleMeanRSforMS[i],ffFixed,8,2) + "\t";
            else
             Tstr = Tstr + "na\t";
            if (usedMSstdev[i] == true)
             Tstr = Tstr + FloatToStrF(meansampleStDevRSforMS[i],ffFixed,8,2) + "\t";
            else
             Tstr = Tstr + "na\t";
        }

        Tstr = Tstr + FloatToStrF(sAveMSmean,ffFixed,4,4) + "\t" + FloatToStrF(sAveRSmean,ffFixed,4,4) + "\t";
        Tstr = Tstr + FloatToStrF(sSDmsmean,ffFixed,4,4) + "\t" + FloatToStrF(sSDrsmean,ffFixed,4,4) + "\t" +
               FloatToStrF(sBGmean,ffFixed,4,4) + "\t";

        Tstr = Tstr + FloatToStrF(rAveMSmean,ffFixed,8,3) + "\t" + FloatToStrF(rAveRSmean,ffFixed,8,3) + "\t";
        Tstr = Tstr + FloatToStrF(rSDmsmean,ffFixed,8,3) + "\t" + FloatToStrF(rSDrsmean,ffFixed,8,3) + "\t" +
               FloatToStrF(rBGmean,ffFixed,8,3) + "\t" + FloatToStrF(rBGnzmean,ffFixed,8,3) + "\t"
               + FloatToStrF(rBGprimemean,ffFixed,8,3) + "\t"
               + FloatToStrF(Ismean,ffFixed,8,3) + "\t" + FloatToStrF(Imean,ffFixed,8,3) + "\t"
               + FloatToStrF(rSmaxmean,ffFixed,8,3) + "\t";

        Tstr = Tstr + FloatToStrF(ChiSqrmean,ffFixed,8,3);
        if (!globalBigRun)
          RichEdit1->Lines->Add(Tstr);

        if (ChiSqrmean < LowestChiSquare)
        {
           LowestChiSquare = ChiSqrmean;
           EstMeanMS = rAveMSmean;
           EstMeanRS = rAveRSmean;
           EstStdDevMS = rSDmsmean;
           EstStdDevRS = rSDrsmean;
           EstBatemanGradient = rBGmean;
           EstBGnz = rBGnzmean;
           EstBGprime = rBGprimemean;
           EstSmax = rSmaxmean;

           OppSel = Imean;
           OppSexSel = Ismean;

           globalBestStDevMS = SigmaMS;
           globalBestStDevRS = SigmaRS;
           globalBestCorr = corrMSRS;

           toponecorrMSRS = corrMSRS;
           toponeSigmaRS = SigmaRS;
        }

        j = 0;
        for (i = 0; i < 10; i++)
        {
           if (ChiSqrmean > toptenChiSqr[i])
              j = i+1;
        }

        if (j < 10)
        {
           for (i = 9; i > j; i--)
           {
                toptenChiSqr[i] = toptenChiSqr[i-1];
                toptenMS[i] = toptenMS[i-1];
                toptenRS[i] = toptenRS[i-1];
                toptenSDms[i] = toptenSDms[i-1];
                toptenSDrs[i] = toptenSDrs[i-1];
                toptenBG[i] = toptenBG[i-1];
                toptenI[i] = toptenI[i-1];
                toptenIs[i] = toptenIs[i-1];
                toptenBGnz[i] = toptenBGnz[i-1];
                toptencorrMSRS[i] = toptencorrMSRS[i-1];
                toptenSigmaRS[i] = toptenSigmaRS[i-1];
                toptenBGprime[i] = toptenBGprime[i-1];
                toptenSmax[i] = toptenSmax[i-1];
           }

           toptenChiSqr[j] = ChiSqrmean;
           toptenMS[j] = rAveMSmean;
           toptenRS[j] = rAveRSmean;
           toptenSDms[j] = rSDmsmean;
           toptenSDrs[j] = rSDrsmean;
           toptenBG[j] = rBGmean;
           toptenI[j] = Imean;
           toptenIs[j] = Ismean;
           toptenChiSqr[j] = ChiSqrmean;
           toptenBGnz[j] = rBGnzmean;
           toptencorrMSRS[j] = corrMSRS;
           toptenSigmaRS[j] = SigmaRS;
           toptenBGprime[j] = rBGprimemean;
           toptenSmax[j] = rSmaxmean;
        }

       }// end of n
       }// end of o


     if (!globalBigRun)
     {
       RichEdit1->Lines->Add(" ");
       RichEdit1->Lines->Add("Single Best Solution:");
       Tstr = ("Mean MS:    \t") + FloatToStrF(EstMeanMS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("Mean RS:    \t") + FloatToStrF(EstMeanRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("StDev MS:   \t") + FloatToStrF(EstStdDevMS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("StDev RS:   \t") + FloatToStrF(EstStdDevRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("BateGrad:   \t") + FloatToStrF(EstBatemanGradient,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("BG,no 0s:   \t") + FloatToStrF(EstBGnz,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("BG':            \t") + FloatToStrF(EstBGprime,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("Is:               \t") + FloatToStrF(OppSexSel,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("I:                \t") + FloatToStrF(OppSel,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("S'max:          \t") + FloatToStrF(EstSmax,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("RS incr./mate:\t") + FloatToStrF(toponecorrMSRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("StDev RS param.\t") + FloatToStrF(toponeSigmaRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);

       RichEdit1->Lines->Add(" ");
       RichEdit1->Lines->Add("Top Ten Solutions:");
       RichEdit1->Lines->Add("AveMS\tAveRS\tSDms\tSDrs\tIs\tI\tBG\tBGno0s\tBG'\tS'max\tChiSqr");
       for (i = 0; i < 10; i++)
       {
         Tstr = FloatToStrF(toptenMS[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenRS[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenSDms[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenSDrs[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenIs[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenI[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenBG[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenBGnz[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenBGprime[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenSmax[i],ffFixed,8,3) + "\t";
         Tstr = Tstr + FloatToStrF(toptenChiSqr[i],ffFixed,8,3) + "\t";
         RichEdit1->Lines->Add(Tstr);
       }
     }
       // estimates based on top ten

           EstMeanMS = Mean(toptenMS,9);
           EstMeanRS = Mean(toptenRS,9);
           EstStdDevMS = Mean(toptenSDms,9);
           EstStdDevRS = Mean(toptenSDrs,9);
           EstBatemanGradient = Mean(toptenBG,9);
           EstBGnz = Mean(toptenBGnz,9);
           OppSel = Mean(toptenI,9);
           OppSexSel = Mean(toptenIs,9);
           toponecorrMSRS = Mean(toptencorrMSRS,9);
           toponeSigmaRS = Mean(toptenSigmaRS,9);
           EstBGprime = Mean(toptenBGprime,9);
           EstSmax = Mean(toptenSmax,9);

     if (!globalBigRun)
     {
       RichEdit1->Lines->Add(" ");
       RichEdit1->Lines->Add("Mean of the Top 10 Solutions:");
       Tstr = ("Mean MS:    \t") + FloatToStrF(EstMeanMS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("Mean RS:    \t") + FloatToStrF(EstMeanRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("StDev MS:   \t") + FloatToStrF(EstStdDevMS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("StDev RS:   \t") + FloatToStrF(EstStdDevRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("BateGrad:   \t") + FloatToStrF(EstBatemanGradient,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("BG,no 0s:   \t") + FloatToStrF(EstBGnz,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("BG':           \t") + FloatToStrF(EstBGprime,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("Is:              \t") + FloatToStrF(OppSexSel,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("I:               \t") + FloatToStrF(OppSel,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("S'max:         \t") + FloatToStrF(EstSmax,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("RS incr./mate:\t") + FloatToStrF(toponecorrMSRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
       Tstr = ("StDev RS param.\t") + FloatToStrF(toponeSigmaRS,ffFixed,8,3);
       RichEdit1->Lines->Add(Tstr);
     }

      globalResultsEstSDRS = EstStdDevRS;
      globalResultsEstBG = EstBatemanGradient;
      globalResultsEstBGnz = EstBGnz;
      globalResultsEstI = OppSel;
      globalResultscorrMSRS = toponecorrMSRS;
      globalResultsSigmaRS = toponeSigmaRS;

      globalcorrMSRS = toponecorrMSRS;
      globalSigmaRS = toponeSigmaRS;

      globalResultsBGprime = EstBGprime;
      globalResultsSmax = EstSmax;

       if (RichEdit1->Visible == false)
		  RichEdit1->Show();

		EnableUI->Execute();

        for (i = 0; i < 20; i++)
		delete[] RSfirstMSthenInd[i];
        delete[] RSfirstMSthenInd;
        delete[] ClutchFather;
        delete[] ClutchSize;
        delete[] ClutchSampled;
        delete[] RealFatherMS;
        delete[] RealFatherRS;
        delete[] tempNinClutch;
        delete[] sampleCF;
        delete[] sampleCS;
        delete[] ApparentFMS;
        delete[] ApparentFRS;
        delete[] truncAppFMS;
        delete[] truncAppFRS;
        delete[] realFMS;
        delete[] realFRS;
        delete[] realFMStrunc;
        delete[] realFRStrunc;


}
//---------------------------------------------------------------------------



void __fastcall TForm1::LoadDataExecute(TObject *Sender)
{

        int LDi;
        AnsiString LDstr;

        Form2->Edit1->Text = FloatToStr(globalFemaleMeanMS);
        Form2->Edit2->Text = FloatToStr(globalFemaleMeanRS);
        Form2->Edit3->Text = FloatToStr(globalSexRatio);
        Form2->Edit4->Text = FloatToStr(globalEstimatedNumberMales);
        Form2->Edit5->Text = FloatToStr(globalClutchesSampled);
        Form2->Edit6->Text = FloatToStr(globalEstimationSDMS);
        Form2->Edit7->Text = FloatToStr(globalNrsIntervals);
        Form2->Edit8->Text = FloatToStr(globalEstReps);
        Form2->Edit9->Text = FloatToStr(globalBootReps);
        Form2->Edit10->Text = FloatToStr(globalRSstddevmax);
        Form2->Edit11->Text = FloatToStr(globalMSstddevmax);
        Form2->Edit12->Text = FloatToStr(globalNmsintervals);
        Form2->Edit13->Text = FloatToStr(globalRSperMatemax);
        Form2->Edit14->Text = FloatToStr(globalRSperMSintervals);
        Form2->Edit15->Text = FloatToStr(globalcorrMSRS);
        Form2->Edit16->Text = FloatToStr(globalSigmaRS);

        Form2->RichEdit1->Clear();
        for (LDi = 0; LDi < globalNmaleData; LDi++)
        {
          LDstr = FloatToStr(globalMaleMS[LDi]) + "\t" + FloatToStr(globalMaleRS[LDi]);
          Form2->RichEdit1->Lines->Add(LDstr);
        }
		Form2->ShowModal();


}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject *Sender)
{
        delete[] globalMaleMS;
        delete[] globalMaleRS;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::BootStrapExecute(TObject *Sender)
{
        int i, j, k, l, m, n, o, reps;

        int Nmales, Nclutches;
        double MeanMS;
        double MeanRS;
        double SigmaMS;
        double SigmaRS;
        double corrMSRS;
        AnsiString Tstr;
        double tempMS, tempRS, remainder;
        int rndi;
        int NclutchesSampled;
        double DataStDevMS, DataStDevRS, DataStDevSingleMaters, DataBatemanGradient;
        int Ntrunc;
        double dub1, dub2;
        double sampleStdDevMS, sampleStdDevRS, sampleBatemanGradient, sampleStdDevSingleMaters;
        int Nsinglematers;
        double sampleMeanMS, sampleMeanRS, sampleCov;
        double realMeanMS, realMeanRS, realStdDevMS, realStdDevRS, realBG, realCov;
        double chiSqr;
        double sAveMSmean, sAveRSmean, sSDmsmean, sSDrsmean, sSD1matmean, sBGmean, rAveMSmean,
               rAveRSmean, rSDmsmean, rSDrsmean, rBGmean, ChiSqrmean;
        int totalreps;
		double LowestChiSquare, EstMeanMS, EstMeanRS, EstStdDevMS, EstStdDevRS, EstBatemanGradient;
        double OppSel, OppSexSel;
        int NmaleDataInt, dataNsinglematers;
        double dataMeanMS, dataMeanRS, dataVarMS, dataCov;
        int iNmsIntervals, iNrsIntervals;
		double sizeMSinter, sizeRSinter;

        int iBootReps, boot;

        iBootReps = globalBootReps;
        double *resultMSstddev = new double[iBootReps];
        double *resultRSstddev = new double[iBootReps];
        double *resultBG = new double[iBootReps];
        double *resultI = new double[iBootReps];
        double *resultIs = new double[iBootReps];
        double *resultMSmean = new double[iBootReps];
        double *resultRSmean = new double[iBootReps];

        NmaleDataInt = globalNmaleData;
        double *DataSingleMaterRS = new double[NmaleDataInt];
        double *bootMaleMS = new double[NmaleDataInt];
        double *bootMaleRS = new double[NmaleDataInt];

        MeanMS = (globalFemaleMeanMS * (1 - globalSexRatio))/globalSexRatio;  // Mean is from the collected sex
        MeanRS = (globalFemaleMeanRS * (1 - globalSexRatio))/globalSexRatio;  // Mean is from the collected sex
        Nmales = globalEstimatedNumberMales;           // Estimated total number of the uncollected sex
        NclutchesSampled = globalClutchesSampled; // Nclutches sampled from the data
        iNmsIntervals = globalNmsIntervals;
        iNrsIntervals = globalNrsIntervals;
        sizeMSinter = (3*MeanMS)/globalNmsIntervals;
        sizeRSinter = (3*MeanRS)/globalNrsIntervals;

        int *ClutchFather = new int[20000];
        int *ClutchSize = new int[20000];
        int *ClutchSampled = new int[20000];
        int *RealFatherMS = new int[Nmales];
        int *RealFatherRS = new int[Nmales];
        int *tempNinClutch = new int[100];
        int *sampleCF = new int[5000];
        int *sampleCS = new int[5000];
        int *ApparentFMS = new int[Nmales];
        int *ApparentFRS = new int[Nmales];
        double *truncAppFMS = new double[Nmales];
        double *truncAppFRS = new double[Nmales];
        double *singlematersRS = new double[Nmales];
        double *realFMS = new double[Nmales];
        double *realFRS = new double[Nmales];
        double tempMeanMS, tempMeanRS;

		int tenpercentofreps = iBootReps/10;
		MSG winmsg;

   for (boot = 0; boot < iBootReps; boot++)
   {
		if ((boot+1) % tenpercentofreps == 0) {
		   RichEdit1->Lines->SaveToFile(LogFileName + IntToStr(boot) + "bootstrapsComplete.txt");
		}

		if (PeekMessage(&winmsg,NULL,0,0,PM_REMOVE)) {
			TranslateMessage(&winmsg);
			DispatchMessage(&winmsg);
		}

        for (i = 0; i < NmaleDataInt; i++)
        {
           rndi = randnum(NmaleDataInt);
           bootMaleMS[i] = globalMaleMS[rndi];
           bootMaleRS[i] = globalMaleRS[rndi];
        } // end of i

        DataStDevMS = StdDev(bootMaleMS,NmaleDataInt-1);  // from the unknown sex
        DataStDevRS = StdDev(bootMaleRS,NmaleDataInt-1);  // from the unknown sex

        dataMeanMS = Mean(bootMaleMS,NmaleDataInt-1);
        dataMeanRS = Mean(bootMaleRS,NmaleDataInt-1);
        dataVarMS = Variance(bootMaleMS,NmaleDataInt-1);

        dub1 = 0;
        dub2 = 0;

        for (i = 0; i < NmaleDataInt; i++)
        {
          dub1 = dub1 + (bootMaleMS[i] - dataMeanMS) * (bootMaleRS[i] - dataMeanRS);
          dub2 = dub2 + 1;
        }

        if (dub2 > 1)
          dataCov = dub1/(dub2-1);
        else
          dataCov = 0;

        if (dataVarMS > 0)
          DataBatemanGradient = dataCov/dataVarMS;
        else
          DataBatemanGradient = 0;

        dataNsinglematers = 0;
        for (i = 0; i < NmaleDataInt; i++)
        {
          if (bootMaleMS[i] == 1)
          {
             DataSingleMaterRS[dataNsinglematers] = bootMaleRS[i];
             dataNsinglematers++;
          }
        }

        DataStDevSingleMaters = StdDev(DataSingleMaterRS,dataNsinglematers-1); // from the unknown sex

        SigmaMS = 0;
        SigmaRS = 0;
        totalreps = globalEstReps;

       // Tstr = "dAveMS\tdAveRS\tdSDms\tdSDrs\tdBG\tdSD1mat\tpSDms\tpSDrs\tpRmsrs\tpNmale\tpNcltch\t";
       // Tstr = Tstr + "sAveMS\tsAveRS\tsSDms\tsSDrs\tsSD1mat\tsBG\trAveMS\trAveRS\trSDms\trSDrs\trBG\tChiSqr";
       // RichEdit1->Lines->Add(Tstr);

        LowestChiSquare = 100000;

       for (m = 0; m < iNmsIntervals; m++)
       {
          SigmaMS = SigmaMS + sizeMSinter;
          SigmaRS = 0;

       for (n = 0; n < iNrsIntervals; n++)
       {
          SigmaRS = SigmaRS + sizeRSinter;
          corrMSRS = -0.6;

       for (o = 0; o < 15; o++)
       {
          corrMSRS = corrMSRS + 0.1;

          rndi = randnum(2);
          if (rndi == 0)
             StatusBar1->SimpleText = "@#!*";
          else
             StatusBar1->SimpleText = "    ";
          StatusBar1->Update();

          sAveMSmean = 0;
          sAveRSmean = 0;
          sSDmsmean = 0;
          sSDrsmean = 0;
          sSD1matmean = 0;
          sBGmean = 0;
          rAveMSmean = 0;
          rAveRSmean = 0;
          rSDmsmean = 0;
          rSDrsmean = 0;
          rBGmean = 0;
          ChiSqrmean = 0;

        //   Tstr = FloatToStrF(MeanMS,ffFixed,8,3) + "\t" + FloatToStrF(MeanRS,ffFixed,8,3) + "\t";
        //   Tstr = Tstr + FloatToStrF(DataStDevMS,ffFixed,8,3) + "\t" + FloatToStrF(DataStDevRS,ffFixed,8,3) + "\t";
        //   Tstr = Tstr + FloatToStrF(DataBatemanGradient,ffFixed,8,3) + "\t" + FloatToStrF(DataStDevSingleMaters,ffFixed,8,3) + "\t";
        //   Tstr = Tstr + FloatToStrF(SigmaMS,ffFixed,8,3) + "\t" + FloatToStrF(SigmaRS,ffFixed,8,3) + "\t";
        //   Tstr = Tstr + FloatToStrF(corrMSRS,ffFixed,8,3) + "\t" + IntToStr(Nmales) + "\t";
        //   Tstr = Tstr + IntToStr(NclutchesSampled) + "\t";

       for (reps = 0; reps < totalreps; reps++)
       {

           Nclutches = 0;

        // Assign male MS and RS
        for (i = 0; i < Nmales; i++)
        {
           randbivnorm(SigmaMS,SigmaRS,corrMSRS);
           realFMS[i] = bivN1 + MeanMS;
           realFRS[i] = bivN2 + MeanRS;
        } // end of i

        // allow negative values of ms and rs for statistical purposes
        //for (i = 0; i < Nmales; i++)
        //{
        //   if (realFRS[i] < 0)
        //      realFRS[i] = 0;
        //   if (realFRS[i] < 0.5)
        //      realFMS[i] = 0;
        //   if (realFMS[i] < 0)
        //       realFMS[i] = 0;
        //   if (realFMS[i] < 0.5)
        //       realFRS[i] = 0;
        //} // end of i

        // rescale values to get the correct mean MS and mean RS

        tempMeanMS = Mean(realFMS,Nmales-1);
        tempMeanRS = Mean(realFRS,Nmales-1);

        for (i = 0; i < Nmales; i++)
        {
           realFMS[i] = realFMS[i] * (MeanMS/tempMeanMS);
           realFRS[i] = realFRS[i] * (MeanRS/tempMeanRS);
        } // end of i

        // round all values to the nearest integer and assign clutch sizes

        for (i = 0; i < Nmales; i++)
        {
           tempMS = realFMS[i];
           tempRS = realFRS[i];
           remainder = tempMS - floor(tempMS);
           if (remainder >= 0.5)
              tempMS = floor(tempMS) + 1;
           else
              tempMS = floor(tempMS);

           remainder = tempRS - floor(tempRS);
           if (remainder >= 0.5)
              tempRS = floor(tempRS) + 1;
           else
              tempRS = floor(tempRS);

           RealFatherMS[i] = tempMS;
           RealFatherRS[i] = tempRS;

          // if (RealFatherMS[i] < 0)
          //    RealFatherMS[i] = 0;

          // if (RealFatherRS[i] < 0)
          //    RealFatherRS[i] = 0;

          // if (RealFatherMS[i] == 0)
          //    RealFatherRS[i] = 0;

          // if (RealFatherRS[i] == 0)
          //    RealFatherMS[i] = 0;

           //Tstr = IntToStr(RealFatherMS[i]) + "\t" + IntToStr(RealFatherRS[i]);
           //RichEdit1->Lines->Add(Tstr);

           for (j = 0; j < RealFatherMS[i]; j++)
              tempNinClutch[j] = 0;

           for (j = 0; j < RealFatherRS[i]; j++)
           {
              rndi = randnum(RealFatherMS[i]);
              tempNinClutch[rndi]++;
           } // end of j

           for (j = 0; j < RealFatherMS[i]; j++)
           {
              ClutchFather[Nclutches] = i;
              ClutchSize[Nclutches] = tempNinClutch[j];
              Nclutches++;
           } // end of j
        } // end of i


        //for (i = 0; i < Nclutches; i++)
        //{
        //   Tstr = IntToStr(ClutchFather[i]) + "\t" + IntToStr(ClutchSize[i]);
        //   RichEdit1->Lines->Add(Tstr);
        //}  // end of i

        // Now sample clutches

        for (i = 0; i < Nclutches; i++)
           ClutchSampled[i] = 0;

        if (NclutchesSampled > Nclutches)
           NclutchesSampled = Nclutches;

        //RichEdit1->Lines->Add("Sample");
        for (i = 0; i < NclutchesSampled; i++)
        {
           rndi = randnum(Nclutches);
           while (ClutchSampled[rndi] == 1)
              rndi = randnum(Nclutches);
           sampleCF[i] = ClutchFather[rndi];
           sampleCS[i] = ClutchSize[rndi];
           ClutchSampled[rndi] = 1;

           //Tstr = IntToStr(sampleCF[i]) + "\t" + IntToStr(sampleCS[i]);
           //RichEdit1->Lines->Add(Tstr);
        } // end of i

        // calculate apparent RS and MS

        //RichEdit1->Lines->Add("Apparent MS and RS");

        for (i = 0; i < Nmales; i++)
        {
           ApparentFMS[i] = 0;
           ApparentFRS[i] = 0;
        }

        for (i = 0; i < Nmales; i++)
        {
           for (j = 0; j < NclutchesSampled; j++)
           {
               if (sampleCF[j] == i)
               {
                 ApparentFMS[i]++;
                 ApparentFRS[i] = ApparentFRS[i] + sampleCS[j];
               }
           } // end of j

          // Tstr = IntToStr(ApparentFMS[i]) + "\t" + IntToStr(ApparentFRS[i]);
          // RichEdit1->Lines->Add(Tstr);

        } // end of i

        Ntrunc = 0;

        for (i = 0; i < Nmales; i++)
        {
           if (ApparentFMS[i] > 0)
           {
              truncAppFMS[Ntrunc] = ApparentFMS[i];
              truncAppFRS[Ntrunc] = ApparentFRS[i];
              Ntrunc++;
           }
        } // end of i

        Nsinglematers = 0;
        for (i = 0; i < Nmales; i++)
        {
           if (ApparentFMS[i] == 1)
           {
             singlematersRS[Nsinglematers] = ApparentFRS[i];
             Nsinglematers++;
           }

        } // end of i

        //for (i = 0; i < Ntrunc; i++)
        //{
        //   Tstr = FloatToStr(truncAppFMS[i]) + "\t" + FloatToStr(truncAppFRS[i]);
        //   RichEdit1->Lines->Add(Tstr);
        //} // end of i

        // Calculate Bateman Gradients and so on for the sample

        sampleStdDevMS = StdDev(truncAppFMS,Ntrunc-1);
        sampleStdDevRS = StdDev(truncAppFRS,Ntrunc-1);
        sampleStdDevSingleMaters = StdDev(singlematersRS,Nsinglematers-1);

        sampleMeanMS = Mean(truncAppFMS,Ntrunc-1);
        sampleMeanRS = Mean(truncAppFRS,Ntrunc-1);

        dub1 = 0;
        dub2 = 0;
        for (i = 0; i < Ntrunc; i++)
        {
          dub1 = dub1 + (truncAppFMS[i] - sampleMeanMS) * (truncAppFRS[i] - sampleMeanRS);
          dub2 = dub2 + 1;
        }

        sampleCov = dub1/(dub2 - 1);

        if (sampleStdDevMS > 0)
          sampleBatemanGradient = sampleCov/(sampleStdDevMS * sampleStdDevMS);
        else
          sampleBatemanGradient = 0;


        for (i = 0; i < Nmales; i++)
        {
          realFMS[i] = RealFatherMS[i];
          realFRS[i] = RealFatherRS[i];
        } // end of i

        realMeanMS = Mean(realFMS,Nmales-1);
        realMeanRS = Mean(realFRS,Nmales-1);
        realStdDevMS = StdDev(realFMS,Nmales-1);
        realStdDevRS = StdDev(realFRS,Nmales-1);

        dub1 = 0;
        dub2 = 0;
        for (i = 0; i < Nmales; i++)
        {
          dub1 = dub1 + (realFMS[i] - realMeanMS) * (realFRS[i] - realMeanRS);
          dub2 = dub2 + 1;
        }

        if (realStdDevMS > 0)
        {
          realCov = dub1/(dub2 - 1);
          realBG = realCov/(realStdDevMS * realStdDevMS);
        }
        else
        {
          realBG = 0;
        }

        // Calculate Chi-square

        chiSqr = 0;

        if (DataStDevMS > 0)
          chiSqr = chiSqr + (sampleStdDevMS - DataStDevMS) * (sampleStdDevMS - DataStDevMS)/DataStDevMS;
        if (DataStDevRS > 0)
          chiSqr = chiSqr + (sampleStdDevRS - DataStDevRS) * (sampleStdDevRS - DataStDevRS)/DataStDevRS;
        if (DataStDevSingleMaters > 0)
          chiSqr = chiSqr + (sampleStdDevSingleMaters - DataStDevSingleMaters) * (sampleStdDevSingleMaters - DataStDevSingleMaters)/DataStDevSingleMaters;
        if (DataBatemanGradient > 0)
          chiSqr = chiSqr + (sampleBatemanGradient - DataBatemanGradient) * (sampleBatemanGradient - DataBatemanGradient)/DataBatemanGradient;

        sAveMSmean = sAveMSmean + sampleMeanMS;
        sAveRSmean = sAveRSmean + sampleMeanRS;
        sSDmsmean = sSDmsmean + sampleStdDevMS;
        sSDrsmean = sSDrsmean + sampleStdDevRS;
        sSD1matmean = sSD1matmean + sampleStdDevSingleMaters;
        sBGmean = sBGmean + sampleBatemanGradient;
        rAveMSmean = rAveMSmean + realMeanMS;
        rAveRSmean = rAveRSmean + realMeanRS;
        rSDmsmean = rSDmsmean + realStdDevMS;
        rSDrsmean = rSDrsmean + realStdDevRS;
        rBGmean = rBGmean + realBG;
        ChiSqrmean = ChiSqrmean + chiSqr;

       } // end of reps

        dub2 = totalreps;
        sAveMSmean = sAveMSmean/dub2;
        sAveRSmean = sAveRSmean/dub2;
        sSDmsmean = sSDmsmean/dub2;
        sSDrsmean = sSDrsmean/dub2;
        sSD1matmean = sSD1matmean/dub2;
        sBGmean = sBGmean/dub2;
        rAveMSmean = rAveMSmean/dub2;
        rAveRSmean = rAveRSmean/dub2;
        rSDmsmean = rSDmsmean/dub2;
        rSDrsmean = rSDrsmean/dub2;
        rBGmean = rBGmean/dub2;
        ChiSqrmean = ChiSqrmean/dub2;

       // Tstr = Tstr + FloatToStrF(sAveMSmean,ffFixed,4,4) + "\t" + FloatToStrF(sAveRSmean,ffFixed,4,4) + "\t";
       // Tstr = Tstr + FloatToStrF(sSDmsmean,ffFixed,4,4) + "\t" + FloatToStrF(sSDrsmean,ffFixed,4,4) + "\t" +
       //        FloatToStrF(sSD1matmean,ffFixed,4,4) + "\t" + FloatToStrF(sBGmean,ffFixed,4,4) + "\t";

       // Tstr = Tstr + FloatToStrF(rAveMSmean,ffFixed,8,3) + "\t" + FloatToStrF(rAveRSmean,ffFixed,8,3) + "\t";
       // Tstr = Tstr + FloatToStrF(rSDmsmean,ffFixed,8,3) + "\t" + FloatToStrF(rSDrsmean,ffFixed,8,3) + "\t" +
       //        FloatToStrF(rBGmean,ffFixed,8,3) + "\t";

       // Tstr = Tstr + FloatToStrF(ChiSqrmean,ffFixed,8,3);
       // RichEdit1->Lines->Add(Tstr);

        if (ChiSqrmean < LowestChiSquare)
        {
           LowestChiSquare = ChiSqrmean;
           EstMeanMS = rAveMSmean;
           EstMeanRS = rAveRSmean;
           EstStdDevMS = rSDmsmean;
           EstStdDevRS = rSDrsmean;
           EstBatemanGradient = rBGmean;

           OppSel = (EstStdDevRS*EstStdDevRS)/(EstMeanRS*EstMeanRS);
           OppSexSel = (EstStdDevMS*EstStdDevMS)/(EstMeanMS*EstMeanMS);
        }

       }// end of m
       }// end of n
       }// end of o

       Tstr = "Bootstrap Rep: \t" + IntToStr(boot+1) + "\t";
       Tstr = Tstr + ("Mean MS: \t") + FloatToStrF(EstMeanMS,ffFixed,8,3) + "\t";
       Tstr = Tstr + ("Mean RS: \t") + FloatToStrF(EstMeanRS,ffFixed,8,3) + "\t";
       Tstr = Tstr + ("StDev MS:\t") + FloatToStrF(EstStdDevMS,ffFixed,8,3) + "\t";
       Tstr = Tstr + ("StDev RS:\t") + FloatToStrF(EstStdDevRS,ffFixed,8,3) + "\t";
       Tstr = Tstr + ("BateGrad:\t") + FloatToStrF(EstBatemanGradient,ffFixed,8,3) + "\t";
       Tstr = Tstr + ("I:       \t") + FloatToStrF(OppSel,ffFixed,8,3) + "\t";
       Tstr = Tstr + ("Is:      \t") + FloatToStrF(OppSexSel,ffFixed,8,3) + "\t";
       RichEdit1->Lines->Add(Tstr);

       resultMSmean[boot] = EstMeanMS;
       resultRSmean[boot] =  EstMeanRS;
       resultMSstddev[boot] = EstStdDevMS;
       resultRSstddev[boot] = EstStdDevRS;
       resultBG[boot] = EstBatemanGradient;
       resultI[boot] = OppSel;
       resultIs[boot] = OppSexSel;

   } // end of boot


 //  RichEdit1->Lines->Add("meanMS\tmeanRS\tSDms\tSDrs\tI\tI(S)\tBG");

 //  for (i = 0; i < iBootReps; i++)
 //  {
 //     Tstr = FloatToStrF(resultMSmean[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultRSmean[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultMSstddev[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultRSstddev[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultI[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultIs[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultBG[i],ffFixed,8,3);
 //     RichEdit1->Lines->Add(Tstr);
 //  }  // end of i

   // sort each of these lists from lowest to highest

   double *BootSortList = new double[iBootReps+1];
   int BSLsize;

   BSLsize = 1;
   BootSortList[0] = resultMSmean[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultMSmean[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultMSmean[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultMSmean[i] = BootSortList[i];

   BSLsize = 1;
   BootSortList[0] = resultRSmean[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultRSmean[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultRSmean[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultRSmean[i] = BootSortList[i];

   BSLsize = 1;
   BootSortList[0] = resultMSstddev[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultMSstddev[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultMSstddev[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultMSstddev[i] = BootSortList[i];

   BSLsize = 1;
   BootSortList[0] = resultRSstddev[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultRSstddev[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultRSstddev[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultRSstddev[i] = BootSortList[i];

   BSLsize = 1;
   BootSortList[0] = resultI[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultI[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultI[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultI[i] = BootSortList[i];

   BSLsize = 1;
   BootSortList[0] = resultIs[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultIs[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultIs[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultIs[i] = BootSortList[i];

   BSLsize = 1;
   BootSortList[0] = resultBG[0];
   for (i = 1; i < iBootReps; i++)
   {
      j = 0;
      while (resultBG[i] > BootSortList[j] && j < BSLsize)
        j++;

      for (k = BSLsize; k > j; k--)
         BootSortList[k] = BootSortList[k-1];
      BootSortList[j] = resultBG[i];
      BSLsize++;
   } // end of i
   for (i = 0; i < iBootReps; i++)
      resultBG[i] = BootSortList[i];

 //  RichEdit1->Lines->Add("meanMS\tmeanRS\tSDms\tSDrs\tI\tI(S)\tBG");

 //  for (i = 0; i < iBootReps; i++)
 //  {
 //     Tstr = FloatToStrF(resultMSmean[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultRSmean[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultMSstddev[i],ffFixed,8,3) + "\t" +
 //           FloatToStrF(resultRSstddev[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultI[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultIs[i],ffFixed,8,3) + "\t" +
 //            FloatToStrF(resultBG[i],ffFixed,8,3);
 //     RichEdit1->Lines->Add(Tstr);
 //  }  // end of i

   // Calculate means and Confidence Intervals

   int LowerCIindex, UpperCIindex, MedianIndex1, MedianIndex2;
   dub1 = iBootReps;
   dub2 = dub1 * 0.025;
   dub2 = floor(dub2);
   i = dub2;
   j = iBootReps - i - 1;
   LowerCIindex = i;
   UpperCIindex = j;

   dub1 = j - i + 1;
   dub2 = iBootReps;
   dub1 = dub1/dub2;
   dub1 = dub1*100;

   Tstr = "Variable     \tBS-Mean\tBS-Med\tLowerCI\tUpperCI\t";
   Tstr = Tstr + "(" + FloatToStrF(dub1,ffFixed,4,1) + "%)";

   RichEdit1->Lines->Add(Tstr);

   double finalBSmean, finalBSmedian, finalBSlowerCI, finalBSupperCI;

   // is the median an average or an exact value?  Depends upon whether there is an even number

   if (iBootReps % 2 == 0)
      {
        MedianIndex1 = iBootReps/2 - 1;
        MedianIndex2 = iBootReps/2;
      }
   else
      {
        MedianIndex1 = iBootReps/2;
        MedianIndex2 = iBootReps/2;
      }

   Tstr = "meanMS       \t";
   finalBSmean = Mean(resultMSmean,iBootReps-1);
   finalBSmedian = (resultMSmean[MedianIndex1] + resultMSmean[MedianIndex2])/2;
   finalBSlowerCI = resultMSmean[LowerCIindex];
   finalBSupperCI = resultMSmean[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);


   Tstr = "meanRS       \t";
   finalBSmean = Mean(resultRSmean,iBootReps-1);
   finalBSmedian = (resultRSmean[MedianIndex1] + resultRSmean[MedianIndex2])/2;
   finalBSlowerCI = resultRSmean[LowerCIindex];
   finalBSupperCI = resultRSmean[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);


   Tstr = "stddevMS     \t";
   finalBSmean = Mean(resultMSstddev,iBootReps-1);
   finalBSmedian = (resultMSstddev[MedianIndex1] + resultMSstddev[MedianIndex2])/2;
   finalBSlowerCI = resultMSstddev[LowerCIindex];
   finalBSupperCI = resultMSstddev[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);


   Tstr = "stddevRS     \t";
   finalBSmean = Mean(resultRSstddev,iBootReps-1);
   finalBSmedian = (resultRSstddev[MedianIndex1] + resultRSstddev[MedianIndex2])/2;
   finalBSlowerCI = resultRSstddev[LowerCIindex];
   finalBSupperCI = resultRSstddev[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);


   Tstr = "OppSelec(I)  \t";
   finalBSmean = Mean(resultI,iBootReps-1);
   finalBSmedian = (resultI[MedianIndex1] + resultI[MedianIndex2])/2;
   finalBSlowerCI = resultI[LowerCIindex];
   finalBSupperCI = resultI[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);


   Tstr = "OppSexSel(Is)\t";
   finalBSmean = Mean(resultIs,iBootReps-1);
   finalBSmedian = (resultIs[MedianIndex1] + resultIs[MedianIndex2])/2;
   finalBSlowerCI = resultIs[LowerCIindex];
   finalBSupperCI = resultIs[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);


   Tstr = "BatemanGrad  \t";
   finalBSmean = Mean(resultBG,iBootReps-1);
   finalBSmedian = (resultBG[MedianIndex1] + resultBG[MedianIndex2])/2;
   finalBSlowerCI = resultBG[LowerCIindex];
   finalBSupperCI = resultBG[UpperCIindex];

   Tstr = Tstr + FloatToStrF(finalBSmean,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSmedian,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSlowerCI,ffFixed,6,2) + "\t";
   Tstr = Tstr + FloatToStrF(finalBSupperCI,ffFixed,6,2);

   RichEdit1->Lines->Add(Tstr);

   if (RichEdit1->Visible == false)
          RichEdit1->Show();

        delete[] ClutchFather;
        delete[] ClutchSize;
        delete[] ClutchSampled;
        delete[] RealFatherMS;
        delete[] RealFatherRS;
        delete[] tempNinClutch;
        delete[] sampleCF;
        delete[] sampleCS;
        delete[] ApparentFMS;
        delete[] ApparentFRS;
        delete[] truncAppFMS;
        delete[] truncAppFRS;
        delete[] singlematersRS;
        delete[] realFMS;
        delete[] realFRS;
        delete[] DataSingleMaterRS;
        delete[] bootMaleMS;
        delete[] bootMaleRS;
        delete[] resultMSstddev;
        delete[] resultRSstddev;
        delete[] resultBG;
        delete[] resultI;
        delete[] resultIs;
        delete[] resultMSmean;
        delete[] resultRSmean;
        delete[] BootSortList;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
        Panel1->Hide();
                
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BootstrapDataExecute(TObject *Sender)
{
	  // Disable the menu and action bar
	  DisableUI->Execute();

	  int i, j, k;
      int iBootReps, boot;
      int rndi;
      double CovMSRS;
      double dub1, dub2;
	  AnsiString tStr;

	  MSG winmsg;

      double meanMS, MSMlower, MSMupper, MSMlower90, MSMupper90;
      double meanRS, RSMlower, RSMupper, RSMlower90, RSMupper90;
      double varMS, MSVlower, MSVupper, MSVlower90, MSVupper90;
      double varRS, RSVlower, RSVupper, RSVlower90, RSVupper90;
      double pointIms, Imslower, Imsupper, Imslower90, Imsupper90;
      double pointIrs, Irslower, Irsupper, Irslower90, Irsupper90;
      double pointBG, BGlower, BGupper, BGlower90, BGupper90;
      double pointBGp, BGplower, BGpupper, BGplower90, BGpupper90;
      double pointSmax, Smaxlower, Smaxupper, Smaxlower90, Smaxupper90;

      iBootReps = globalBootReps;

      int NmaleDataInt;

      NmaleDataInt = globalNmaleData;

      double *bootMaleMS = new double[NmaleDataInt];
      double *bootMaleRS = new double[NmaleDataInt];

      double *bootI = new double[iBootReps];
      double *bootIs = new double[iBootReps];
      double *bootBateGrad = new double[iBootReps];
      double *bootMeanMS = new double[iBootReps];
      double *bootMeanRS = new double[iBootReps];
	  double *bootVarMS = new double[iBootReps];
      double *bootVarRS = new double[iBootReps];
	  double *bootSmax = new double[iBootReps];
	  double *bootBGprime = new double[iBootReps];


      RichEdit1->Clear();
      tStr = "BSrep\tmeanMS\tmeanRS\tstdevMS\tstdevRS\tIs(ms)\tI(rs)\tBateGr\tBG'\ts'max";
      RichEdit1->Lines->Add(tStr);

	  int tenpercentofreps;
	  tenpercentofreps = iBootReps/10;

	  Panel1->Show();
	  ProgressBar1->Max = iBootReps;
	  ProgressBar1->Position = 0;

      for (boot = 0; boot < iBootReps; boot++)
	  {
		if (PeekMessage(&winmsg,NULL,0,0,PM_REMOVE)) {
			TranslateMessage(&winmsg);
			DispatchMessage(&winmsg);
        }

         for (i = 0; i < NmaleDataInt; i++)
         {
            rndi = randnum(NmaleDataInt);
            bootMaleMS[i] = globalMaleMS[rndi];
            bootMaleRS[i] = globalMaleRS[rndi];
         } // end of i

         bootMeanMS[boot] = Mean(bootMaleMS,NmaleDataInt-1);
         bootMeanRS[boot] = Mean(bootMaleRS,NmaleDataInt-1);
         bootVarMS[boot] = Variance(bootMaleMS,NmaleDataInt-1);
         bootVarRS[boot] = Variance(bootMaleRS,NmaleDataInt-1);
         bootIs[boot] = bootVarMS[boot]/(bootMeanMS[boot]*bootMeanMS[boot]);
         bootI[boot] = bootVarRS[boot]/(bootMeanRS[boot]*bootMeanRS[boot]);

         dub1 = 0;
         dub2 = 0;
         for (i = 0; i < NmaleDataInt; i++)
         {
           dub1 = dub1 + (bootMaleMS[i] - bootMeanMS[boot]) * (bootMaleRS[i] - bootMeanRS[boot]);
           dub2 = dub2+1;
         } // end of i

         if (dub2 > 1)
           CovMSRS = dub1/(dub2-1);
         else
           CovMSRS = 0;

         if (bootVarMS[boot] > 0)
           bootBateGrad[boot] = CovMSRS/bootVarMS[boot];
         else
           bootBateGrad[boot] = 0;

         bootBGprime[boot] = bootBateGrad[boot] * (bootMeanMS[boot]/bootMeanRS[boot]);
         bootSmax[boot] = bootBGprime[boot] * sqrt(bootIs[boot]);

         // output the results of each bootstrap replicate

         tStr = IntToStr(boot+1) + "\t" + FloatToStrF(bootMeanMS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootMeanRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(sqrt(bootVarMS[boot]),ffFixed,8,2) + "\t" +
                FloatToStrF(sqrt(bootVarRS[boot]),ffFixed,8,2) + "\t" +
                FloatToStrF(bootIs[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootI[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBateGrad[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBGprime[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSmax[boot],ffFixed,8,2);

		 RichEdit1->Lines->Add(tStr);

		if (LogFileName != "NoFile" && CheckBox1->Checked && (boot+1) % tenpercentofreps == 0) {
		   RichEdit1->Lines->SaveToFile(LogFileName + IntToStr(boot+1) + "bootstrapsComplete.txt");
		}

		ProgressBar1->Position++;

      } // end of boot

      // Calculate Point Estimates of the Statistics

         meanMS = Mean(globalMaleMS,NmaleDataInt-1);
         meanRS = Mean(globalMaleRS,NmaleDataInt-1);
         varMS = Variance(globalMaleMS,NmaleDataInt-1);
         varRS = Variance(globalMaleRS,NmaleDataInt-1);
         pointIms = varMS/(meanMS*meanMS);
         pointIrs = varRS/(meanRS*meanRS);

         dub1 = 0;
         dub2 = 0;
         for (i = 0; i < NmaleDataInt; i++)
         {
           dub1 = dub1 + (globalMaleMS[i] - meanMS) * (globalMaleRS[i] - meanRS);
           dub2 = dub2+1;
         } // end of i

         if (dub2 > 1)
           CovMSRS = dub1/(dub2-1);
         else
           CovMSRS = 0;

         if (varMS > 0)
           pointBG = CovMSRS/varMS;
         else
           pointBG = 0;

         pointBGp = pointBG * (meanMS/meanRS);
         pointSmax = pointBGp * sqrt(pointIms);

      // Sort bootstrap lists for each Statistic

      double *bootSortList = new double[iBootReps+1];
      int BSLsize;

      BSLsize = 1;
      bootSortList[0] = bootMeanMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootMeanRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootI[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootI[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootI[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootI[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootIs[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootIs[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootIs[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootIs[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBateGrad[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBateGrad[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBateGrad[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBateGrad[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootVarMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootVarMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootVarMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootVarMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootVarRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootVarRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootVarRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootVarRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBGprime[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBGprime[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBGprime[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBGprime[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSmax[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSmax[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSmax[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSmax[i] = bootSortList[i];

       // output the results of each sorted list

     // RichEdit1->Lines->Add("Sorted:");
     // for (i = 0; i < iBootReps; i++)
     // {
     //    tStr = IntToStr(i+1) + "\t" + FloatToStrF(bootMeanMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootMeanRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootIs[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootI[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootBateGrad[i],ffFixed,8,2);
     //    RichEdit1->Lines->Add(tStr);
     // } // end of i

      // determine BS confidence intervals

      int lowerCIindex, upperCIindex;
      int lowerCIindex90, upperCIindex90;
      double realCI95;
      double realCI90;

     // 95 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.025;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex = i;
      upperCIindex = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI95 = dub1;

    // 90 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.05;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex90 = i;
      upperCIindex90 = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI90 = dub1;

      tStr = " ";
      RichEdit1->Lines->Add(tStr);
      tStr = "Variable       \tEstimate\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI95,ffFixed,4,1) + "%)";
      tStr = tStr + "\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI90,ffFixed,4,1) + "%)";
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanMS         \t";
      tStr = tStr + FloatToStrF(meanMS,ffFixed,8,3) + "\t";
      MSMlower = bootMeanMS[lowerCIindex];
      MSMupper = bootMeanMS[upperCIindex];
      MSMlower90 = bootMeanMS[lowerCIindex90];
      MSMupper90 = bootMeanMS[upperCIindex90];
      tStr = tStr + FloatToStrF(MSMlower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(MSMupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(MSMlower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(MSMupper90,ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanRS         \t";
      tStr = tStr + FloatToStrF(meanRS,ffFixed,8,3) + "\t";
      RSMlower = bootMeanRS[lowerCIindex];
      RSMupper = bootMeanRS[upperCIindex];
      RSMlower90 = bootMeanRS[lowerCIindex90];
      RSMupper90 = bootMeanRS[upperCIindex90];
      tStr = tStr + FloatToStrF(RSMlower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(RSMupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(RSMlower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(RSMupper90,ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "StDevMS     \t";
      tStr = tStr + FloatToStrF(sqrt(varMS),ffFixed,8,3) + "\t";
      MSVlower = bootVarMS[lowerCIindex];
      MSVupper = bootVarMS[upperCIindex];
      MSVlower90 = bootVarMS[lowerCIindex90];
      MSVupper90 = bootVarMS[upperCIindex90];
      tStr = tStr + FloatToStrF(sqrt(MSVlower),ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(sqrt(MSVupper),ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(sqrt(MSVlower90),ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(sqrt(MSVupper90),ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "StDevRS     \t";
      tStr = tStr + FloatToStrF(sqrt(varRS),ffFixed,8,3) + "\t";
      RSVlower = bootVarRS[lowerCIindex];
      RSVupper = bootVarRS[upperCIindex];
      RSVlower90 = bootVarRS[lowerCIindex90];
      RSVupper90 = bootVarRS[upperCIindex90];
      tStr = tStr + FloatToStrF(sqrt(RSVlower),ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(sqrt(RSVupper),ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(sqrt(RSVlower90),ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(sqrt(RSVupper90),ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "OppSexSel(Is)  \t";
      tStr = tStr + FloatToStrF(pointIms,ffFixed,8,3) + "\t";
      Imslower = bootIs[lowerCIindex];
      Imsupper = bootIs[upperCIindex];
      Imslower90 = bootIs[lowerCIindex90];
      Imsupper90 = bootIs[upperCIindex90];
      tStr = tStr + FloatToStrF(Imslower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(Imsupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(Imslower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(Imsupper90,ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "OppSelec(I)    \t";
      tStr = tStr + FloatToStrF(pointIrs,ffFixed,8,3) + "\t";
      Irslower = bootI[lowerCIindex];
      Irsupper = bootI[upperCIindex];
      Irslower90 = bootI[lowerCIindex90];
      Irsupper90 = bootI[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "BatemanGradient\t";
      tStr = tStr + FloatToStrF(pointBG,ffFixed,8,3) + "\t";
      BGlower = bootBateGrad[lowerCIindex];
      BGupper = bootBateGrad[upperCIindex];
      BGlower90 = bootBateGrad[lowerCIindex90];
      BGupper90 = bootBateGrad[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "StandardizedBG\t";
      tStr = tStr + FloatToStrF(pointBGp,ffFixed,8,3) + "\t";
      BGplower = bootBGprime[lowerCIindex];
      BGpupper = bootBGprime[upperCIindex];
      BGplower90 = bootBGprime[lowerCIindex90];
      BGpupper90 = bootBGprime[upperCIindex90];
      tStr = tStr + FloatToStrF(BGplower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(BGpupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(BGplower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(BGpupper90,ffFixed,8,3);
      RichEdit1->Lines->Add(tStr);

      tStr = "S'max         \t";
      tStr = tStr + FloatToStrF(pointSmax,ffFixed,8,3) + "\t";
      Smaxlower = bootSmax[lowerCIindex];
      Smaxupper = bootSmax[upperCIindex];
      Smaxlower90 = bootSmax[lowerCIindex90];
      Smaxupper90 = bootSmax[upperCIindex90];
      tStr = tStr + FloatToStrF(Smaxlower,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(Smaxupper,ffFixed,8,3) + "\t\t";
      tStr = tStr + FloatToStrF(Smaxlower90,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(Smaxupper90,ffFixed,8,3);
	  RichEdit1->Lines->Add(tStr);

	  if (CheckBox1->Checked && LogFileName != "NoFile") {
		   RichEdit1->Lines->SaveToFile(LogFileName + "Results.txt");
	  }

      delete[] bootMaleMS;
      delete[] bootMaleRS;
      delete[] bootI;
      delete[] bootIs;
      delete[] bootBateGrad;
      delete[] bootMeanMS;
      delete[] bootMeanRS;
      delete[] bootVarMS;
      delete[] bootVarRS;
      delete[] bootSortList;
      delete[] bootSmax;
	  delete[] bootBGprime;

	  EnableUI->Execute();


}
//---------------------------------------------------------------------------

void __fastcall TForm1::SampleDistributionExecute(TObject *Sender)
{
     int i, j, k;
     int Nmales;
     double MeanMS, MeanRS;
     double SigmaMS, SigmaRS, corrMSRS;
     double tempMeanMS, tempMeanRS;
     double tempMS, tempRS, remainder;
     AnsiString Tstr;

     RichEdit1->Clear();

     RichEdit1->Lines->Add("MS\tRS");

        Nmales = globalEstimatedNumberMales;
        SigmaMS = globalEstimationSDMS;
        SigmaRS = globalSigmaRS;
        corrMSRS = globalcorrMSRS;
        MeanMS = (globalFemaleMeanMS * (1 - globalSexRatio))/globalSexRatio;
        MeanRS = (globalFemaleMeanRS * (1 - globalSexRatio))/globalSexRatio;

        double *realFMS = new double[Nmales];
        double *realFRS = new double[Nmales];

        // Assign male MS
        tempMeanMS = 0;
        while (tempMeanMS == 0)
        {
          for (i = 0; i < Nmales; i++)
          {
           realFMS[i] = randnorm(MeanMS,SigmaMS);
           if (realFMS[i] < 0)
              realFMS[i] = 0;
          } // end of i
          tempMeanMS = Mean(realFMS,Nmales-1);
        } // end of while

        for (i = 0; i < Nmales; i++) // scale and round
        {
           realFMS[i] = realFMS[i] * (MeanMS/tempMeanMS);
           remainder = realFMS[i] - floor(realFMS[i]);
           if (remainder >= 0.5)
                realFMS[i] = floor(realFMS[i]) + 1;
           else
                realFMS[i] = floor(realFMS[i]);
        } // end of i

        // assign reproductive success

        tempMeanRS = 0;
        while (tempMeanRS == 0)
        {
           for (i = 0; i < Nmales; i++)
           {
             realFRS[i] = randnorm(MeanRS,SigmaRS) + ((realFMS[i]-MeanMS) * corrMSRS);
             if (realFRS[i] < realFMS[i])
                realFRS[i] = realFMS[i];
             if (realFMS[i] == 0)
                realFRS[i] = 0;
           } // end of i
           tempMeanRS = Mean(realFRS,Nmales-1);
        } // end of while

        // round and adjust

        for (i = 0; i < Nmales; i++)
        {
           realFRS[i] = realFRS[i] * (MeanRS/tempMeanRS);
           remainder = realFRS[i] - floor(realFRS[i]);
           if (remainder >= 0.5)
              realFRS[i] = floor(realFRS[i]) + 1;
           else
              realFRS[i] = floor(realFRS[i]);

           if (realFRS[i] < realFMS[i])
              realFRS[i] = realFMS[i];
        } // end of i


        for (i = 0; i < Nmales; i++)
        {
           Tstr = FloatToStr(realFMS[i]) + "\t" + FloatToStr(realFRS[i]);
           RichEdit1->Lines->Add(Tstr);
        } // end of i

        delete[] realFRS;
        delete[] realFMS;


}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton13Click(TObject *Sender)
{
        RichEdit1->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::MatingDistributionExecute(TObject *Sender)
{
	   DisableUI->Execute();

		MSG winmsg;
       int loop1;
       int i, j, k;
       int iNmalesEst;
       int iNmalesData;
       double dNmalesEst, dFemPopSize;
       double dTotalClutches;
       double dSR;
       int iTotalClutches;
       double dRemainder;
       double dub1, dub2;
       int iClutchCounter, iNclutches;
       int iNviabledistributions;
       double dStdDevMS, dMaxStdDev, dStdDevStep;
       int reps;
       double tempMeanMS;
       double dMeanMaleMS;
       int currentFather;
       int ClutchesToSample;
       int iRand;
       double ChiSqr;
       double minChiSqr;
       double bestSolutionStdDevMS;
       double bestSolutionChiSqr;
       double bestSolutionIs;
       double bestSolutionNumberZeros;
       double bestSolutionEstimationStdDevMS;
       double calculatedSDms;
       int loop1max;
       double dMatches, dTotal, dMCprob;
       bool Same;

       double meanStdDevMS, meanChiSqr;
       double MaxLikelihood;

       double ProbInSampleOf[100];
       double partialprob;
       double dN, dn;
       double SumOfProbs;
       double SumOfProbsNoZeros;
       double FactorialTerm;
       double ProbTargetDist;
       double EPdub1, EPdub2;
       double EPtotalNmales;
       double MinStdDevMS;

       int NumberEstReps;

       AnsiString ts;

       if (!globalBigRun)
         RichEdit1->Clear();

       iNmalesEst = globalEstimatedNumberMales;
       dNmalesEst = globalEstimatedNumberMales;
       iNmalesData = globalNmaleData;
       dSR = globalSexRatio;

       dFemPopSize = (dNmalesEst/dSR) * (1-dSR);
       dTotalClutches = dFemPopSize * globalFemaleMeanMS;

       dMeanMaleMS = dTotalClutches/dNmalesEst;
       dMaxStdDev = dMeanMaleMS * globalMSstddevmax;
       dStdDevStep = dMaxStdDev/globalNmsintervals;
       loop1max = globalNmsintervals + 1;

       globalCalculatedMaleMSmean = dMeanMaleMS;

       NumberEstReps = globalEstReps;

       dub1 = floor(dMeanMaleMS);
       dub2 = dMeanMaleMS - dub1;

       if (dub2 > 0 && dub2 < 1)
          MinStdDevMS = sqrt(dub2-dub2*dub2);
       else
          MinStdDevMS = 0;


       int * IsimMaleMS = new int[iNmalesEst];
       double * DsimMaleMS = new double[iNmalesEst];
       int * iClutchFather = new int[100000];
       bool * bClutchSampled = new bool[100000];
       int * IsimMaleMSsample = new int[iNmalesEst];
       int * dataNmalesWithMS = new int[1000];
       int * sampleNmalesWithMS = new int[1000];
       int * simNmalesWithMS = new int[1000];
       double * meanNms = new double[1000];
       double * samplemeanNms = new double[1000];

       double * EPsimMaleMS = new double[1000];
       double * EPsimMaleMSexpectedsample = new double[1000];
       double * EPdataMaleMS = new double[1000];
       double * FTnumerator = new double[10000];
       double * FTdenominator = new double[10000];

       int EPtermcounter;
       double meanExactProb;


       for (i = 0; i < 100; i++)
          dataNmalesWithMS[i] = 0;

       for (i = 0; i < 100; i++)
          EPdataMaleMS[i] = 0;

       for (i = 0; i < iNmalesData; i++)
       {
          if (globalMaleMS[i] == 1) dataNmalesWithMS[1]++;
          if (globalMaleMS[i] == 2) dataNmalesWithMS[2]++;
          if (globalMaleMS[i] == 3) dataNmalesWithMS[3]++;
          if (globalMaleMS[i] == 4) dataNmalesWithMS[4]++;
          if (globalMaleMS[i] == 5) dataNmalesWithMS[5]++;
          if (globalMaleMS[i] == 6) dataNmalesWithMS[6]++;
          if (globalMaleMS[i] == 7) dataNmalesWithMS[7]++;
          if (globalMaleMS[i] == 8) dataNmalesWithMS[8]++;
          if (globalMaleMS[i] > 8) dataNmalesWithMS[9]++;

          j = globalMaleMS[i];
          EPdataMaleMS[j]++;  // this counts up the distribution in the data -- males can have up to 99 mates

       } // end of i

       dn = 0;                          // dn is the number of clutches sampled in the data
       for (i = 0; i < 100; i++)
          dn = dn + EPdataMaleMS[i]*i;  // this is the target distribution for the probability

       ts = "stdevMS\td1\td2\td3\td4\td5\td6\td7\td8\td>8\tsam1\tsam2\tsam3\tsam4\tsam5\tsam6\tsam7\tsam8\tsam>8\t";
       ts = ts + "sim0\tsim1\tsim2\tsim3\tsim4\tsim5\tsim6\tsim7\tsim8\tsim>8\tchisqr\tsdMS(res)\tMCprob\tExactProb";
       if (!globalBigRun)
          RichEdit1->Lines->Add(ts);

       minChiSqr = 1000000;
	   MaxLikelihood = 0;


       dStdDevMS = MinStdDevMS - dStdDevStep;
       for (loop1 = 0; loop1 < loop1max; loop1++)
       {
          dStdDevMS = dStdDevMS + dStdDevStep;

          meanStdDevMS = 0;
          meanChiSqr = 0;
          for (i = 0; i < 10; i++)
            meanNms[i] = 0;

          for (i = 0; i < 100; i++)
            EPsimMaleMS[i] = 0;

          for (i = 0; i < 10; i++)
             samplemeanNms[i] = 0;

          EPtotalNmales = 0;
          dN = 0;

          dMatches = 0;
		  dTotal = 0;



          for (reps = 0; reps < NumberEstReps; reps++)
		  {


                tempMeanMS = 0;
                while (tempMeanMS == 0)
                {
                  for (i = 0; i < iNmalesEst; i++)
                  {
                    IsimMaleMSsample[i] = 0;
                    DsimMaleMS[i] = randnorm(dMeanMaleMS,dStdDevMS);
                    if (DsimMaleMS[i] < 0)
                       DsimMaleMS[i] = 0;
                  }
                  tempMeanMS = Mean(DsimMaleMS,iNmalesEst-1);
                } // end of while -- don't allow all the males to have no MS

                for (i = 0; i < iNmalesEst; i++)
                {
                   DsimMaleMS[i] = DsimMaleMS[i] * (dMeanMaleMS/tempMeanMS);
                   dRemainder = DsimMaleMS[i] - floor(DsimMaleMS[i]);
                   if (dRemainder < 0.5)
                     IsimMaleMS[i] = floor(DsimMaleMS[i]);
                   else
                     IsimMaleMS[i] = floor(DsimMaleMS[i])+1;
                }

                iNclutches = 0;
                for (i = 0; i < iNmalesEst; i++)
                {
                   for (j = 0; j < IsimMaleMS[i]; j++)
                   {
                      iClutchFather[iNclutches] = i;
                      iNclutches++;
                   }
                } // end of i

                dN = dN + iNclutches; // this is the total number of clutches in the hypothsized population for the probability calc

                for (i = 0; i < iNclutches; i++)
                   bClutchSampled[i] = false;

                ClutchesToSample = globalClutchesSampled;
                if (ClutchesToSample > iNclutches)
                   ClutchesToSample = iNclutches;

                for (i = 0; i < ClutchesToSample; i++)
                {
                   iRand = randnum(iNclutches);
                   while (bClutchSampled[iRand])
                      iRand = randnum(iNclutches);

                   currentFather = iClutchFather[iRand];
                   IsimMaleMSsample[currentFather]++;
                   bClutchSampled[iRand] = true;
                } // end of i

                for (i = 0; i < 10; i++)
                {
                        sampleNmalesWithMS[i] = 0;
                        simNmalesWithMS[i] = 0;
                }


                for (i = 0; i < iNmalesEst; i++)
                {
                        if (IsimMaleMSsample[i] == 1) sampleNmalesWithMS[1]++;
                        if (IsimMaleMSsample[i] == 2) sampleNmalesWithMS[2]++;
                        if (IsimMaleMSsample[i] == 3) sampleNmalesWithMS[3]++;
                        if (IsimMaleMSsample[i] == 4) sampleNmalesWithMS[4]++;
                        if (IsimMaleMSsample[i] == 5) sampleNmalesWithMS[5]++;
                        if (IsimMaleMSsample[i] == 6) sampleNmalesWithMS[6]++;
                        if (IsimMaleMSsample[i] == 7) sampleNmalesWithMS[7]++;
                        if (IsimMaleMSsample[i] == 8) sampleNmalesWithMS[8]++;
                        if (IsimMaleMSsample[i] > 8) sampleNmalesWithMS[9]++;

                        if (IsimMaleMS[i] == 0) simNmalesWithMS[0]++;
                        if (IsimMaleMS[i] == 1) simNmalesWithMS[1]++;
                        if (IsimMaleMS[i] == 2) simNmalesWithMS[2]++;
                        if (IsimMaleMS[i] == 3) simNmalesWithMS[3]++;
                        if (IsimMaleMS[i] == 4) simNmalesWithMS[4]++;
                        if (IsimMaleMS[i] == 5) simNmalesWithMS[5]++;
                        if (IsimMaleMS[i] == 6) simNmalesWithMS[6]++;
                        if (IsimMaleMS[i] == 7) simNmalesWithMS[7]++;
                        if (IsimMaleMS[i] == 8) simNmalesWithMS[8]++;
                        if (IsimMaleMS[i] > 8) simNmalesWithMS[9]++;

                        if (IsimMaleMS[i] < 100)
                        {
                           EPsimMaleMS[IsimMaleMS[i]]++;    // this is the actual distribution of mating success in the simulation
                           EPtotalNmales++;
                        }
                } // end of i

                ChiSqr = 0;
                for (i = 1; i < 10; i++)
                {
                  if (dataNmalesWithMS[i] > 0)
                  {
                     dub1 = dataNmalesWithMS[i];
                     dub2 = sampleNmalesWithMS[i];
                     ChiSqr = ChiSqr + (dub2-dub1)*(dub2-dub1)/dub1;
                  }

                }  // end of i

                Same = true;
                for (i = 0; i < 10; i++)
                   if (dataNmalesWithMS[i] != sampleNmalesWithMS[i])
                      Same = false;

                if (Same)
                   dMatches = dMatches + 1;

                dTotal = dTotal + 1;

                for (i = 0; i < iNmalesEst; i++)
                   DsimMaleMS[i] = IsimMaleMS[i];

                calculatedSDms = StdDev(DsimMaleMS,iNmalesEst-1);

                meanChiSqr = meanChiSqr + ChiSqr;
                meanStdDevMS = meanStdDevMS + calculatedSDms;
                for (i = 0; i < 10; i++)
                   meanNms[i] = meanNms[i] + simNmalesWithMS[i];
                for (i = 1; i < 10; i++)
                   samplemeanNms[i] = samplemeanNms[i] + sampleNmalesWithMS[i];


				if (PeekMessage(&winmsg,NULL,0,0,PM_REMOVE)) {
					TranslateMessage(&winmsg);
					DispatchMessage(&winmsg);
                }
          } // end of reps

          dub1 = reps;
          for (i = 0; i < 100; i++)
                   EPsimMaleMS[i] = EPsimMaleMS[i]/dub1;

          EPtotalNmales = EPtotalNmales/dub1;
          dN = dN/dub1;

          EPdub1 = dN - floor(dN);
          if (EPdub1 < 0.5)
             dN = floor(dN);
          else
             dN = floor(dN) + 1;

          if (dn > dN)
             dn = dN;

          // calculate exact probability for the simulated distribution

                SumOfProbs = 0;
                for (j = 0; j < 100; j++)
                {
                    ProbInSampleOf[j] = 0;
                    for (i = j; i < 100; i++)
                    {
                      EPdub1 = i;
                      EPdub2 = j;
                      partialprob = NchooseK(EPdub1,EPdub2)*NchooseK(dN-EPdub1,dn-EPdub2)/NchooseK(dN,dn);

                      partialprob = partialprob * EPsimMaleMS[i]/EPtotalNmales;
                      ProbInSampleOf[j] = ProbInSampleOf[j] + partialprob;
                    } // end of i
                    SumOfProbs = SumOfProbs + ProbInSampleOf[j];
                } // end of j

                EPdub1 = iNmalesData;

                SumOfProbsNoZeros = SumOfProbs - ProbInSampleOf[0];

               // ts = FloatToStr(SumOfProbs);
               // RichEdit1->Lines->Add(ts);

                // calculate expected distribution without zeros

                for (i = 0; i < 100; i++)
                        ProbInSampleOf[i] = ProbInSampleOf[i]/SumOfProbsNoZeros;

               // ts = "Probs:\t";
               // for (j = 1; j < 100; j++)
               //    ts = ts + FloatToStr(ProbInSampleOf[j]) + "\t";
               // RichEdit1->Lines->Add(ts);

                // now calculate the probability of the data given this expected distribution

               // ts = "Dist:\t";
               // for (j = 1; j < 100; j++)
               //    ts = ts + FloatToStr(EPdataMaleMS[j]) + "\t";
               // RichEdit1->Lines->Add(ts);

                ProbTargetDist = 1;
                for (i = 1; i < 100; i++)
                {
                   k = EPdataMaleMS[i];
                   for (j = 0; j < k; j++)
                   {
                      ProbTargetDist = ProbTargetDist * ProbInSampleOf[i];
                   }
                }

                FactorialTerm = 1;
                for (i = 0; i < iNmalesData; i++)
                    FTnumerator[i] = i+1;

                EPtermcounter = 0;
                for (i = 1; i < 100; i++)
                {
                   k = EPdataMaleMS[i];
                   for (j = 0; j < k; j++)
                   {
                      FTdenominator[EPtermcounter] = j+1;
                      EPtermcounter++;
                   }
                } // end of i

                if (EPtermcounter != iNmalesData) RichEdit1->Lines->Add("error");

                for (i = 0; i < iNmalesData; i++)
                   FactorialTerm = FactorialTerm * (FTnumerator[i]/FTdenominator[i]);

               // ts = "FT:\t" + FloatToStr(FactorialTerm);
               // RichEdit1->Lines->Add(ts);

                ProbTargetDist = ProbTargetDist * FactorialTerm;

                //RichEdit1->Lines->Add(FloatToStr(ProbTargetDist));

                meanExactProb = ProbTargetDist;

          dMCprob = dMatches/dTotal;

          dub1 = reps;
          meanChiSqr = meanChiSqr/dub1;
          meanStdDevMS = meanStdDevMS/dub1;
          for (i = 0; i < 10; i++)
                   meanNms[i] = meanNms[i]/dub1;
          for (i = 1; i < 10; i++)
                   samplemeanNms[i] = samplemeanNms[i]/dub1;


          ts = FloatToStrF(dStdDevMS,ffFixed,8,4) + "\t";
          for (i = 1; i < 10; i++)
             ts = ts + IntToStr(dataNmalesWithMS[i]) + "\t";
          for (i = 1; i < 10; i++)
             ts = ts + FloatToStrF(samplemeanNms[i],ffFixed,8,1) + "\t";
          for (i = 0; i < 10; i++)
             ts = ts + FloatToStrF(meanNms[i],ffFixed,8,1) + "\t";
          ts = ts + FloatToStrF(meanChiSqr,ffFixed,8,4) + "\t" + FloatToStrF(meanStdDevMS,ffFixed,8,3)
                        + "\t" + FloatToStr(dMCprob) + "\t" + FloatToStr(meanExactProb);

         if (!globalBigRun)
          RichEdit1->Lines->Add(ts);

          if (meanExactProb > MaxLikelihood)
          {
            bestSolutionStdDevMS = meanStdDevMS;
            bestSolutionIs = (meanStdDevMS*meanStdDevMS)/(dMeanMaleMS*dMeanMaleMS);
            bestSolutionEstimationStdDevMS = dStdDevMS;
            MaxLikelihood = meanExactProb;
          }

       } // end of loop1

        if (!globalBigRun)
        {
          RichEdit1->Lines->Add(" ");
          RichEdit1->Lines->Add("Results:");
          ts = "Mean Male Mating Success: \t" + FloatToStrF(dMeanMaleMS,ffFixed,8,4);
          RichEdit1->Lines->Add(ts);
          ts = "Standard Deviation in MS: \t" + FloatToStrF(bestSolutionStdDevMS,ffFixed,8,4);
          RichEdit1->Lines->Add(ts);
          ts = "Opp. for Sexual Selection:\t" + FloatToStrF(bestSolutionIs,ffFixed,8,4);
          RichEdit1->Lines->Add(ts);
          ts = "Std. Dev. for Simulation: \t" + FloatToStrF(bestSolutionEstimationStdDevMS,ffFixed,8,4);
          RichEdit1->Lines->Add(ts);
        }

          globalEstimationSDMS = bestSolutionEstimationStdDevMS;

          globalResultsEstSDMS = bestSolutionStdDevMS;
          globalResultsEstIs = bestSolutionIs;

		EnableUI->Execute();

      delete[] IsimMaleMS;
      delete[] DsimMaleMS;
      delete[] iClutchFather;
      delete[] bClutchSampled;
      delete[] IsimMaleMSsample;
      delete[] dataNmalesWithMS;
      delete[] sampleNmalesWithMS;
      delete[] simNmalesWithMS;
      delete[] meanNms;
      delete[] samplemeanNms;
      delete[] EPsimMaleMS;
      delete[] EPsimMaleMSexpectedsample;
      delete[] EPdataMaleMS;
      delete[] FTnumerator;
      delete[] FTdenominator;

}
//---------------------------------------------------------------------------


void __fastcall TForm1::SimulateClutchesExecute(TObject *Sender)
{
    // simulate clutches
   int i, j;
   double Arandnum;
   double Brandnum;
   AnsiString tempString;

   double tmeanms, tmeanrs;
   double meanRSsinglematers;
   double increaseRSperMate;
   double SDwithinMSclass;

   double meanMS;
   double stddevMS;
   double meanRS;

   double tempdub1;
   double tempdub2;

   int Nmales;
   int Nclutches;
   int counter;

   int tempint1;

   double propClutchesSampled;
   int NclutchesToSample;

   meanMS = globalmeanMS;
   stddevMS = globalstddevMS;

   meanRS = globalmeanRSsim;
   SDwithinMSclass = globalSDwithinMSclass;
   increaseRSperMate = globalincreaseRSperMate;

   Nmales = globalNmales;

   propClutchesSampled = globalpropClutchesSampled;

   double * maleMS = new double[Nmales];
   double * maleRS = new double[Nmales];
   double * maleRSinsample = new double[Nmales];
   double * maleMSinsample = new double[Nmales];

   for (i = 0; i < Nmales; i++)
   {
       maleMS[i] = randnorm(meanMS, stddevMS);
       if (maleMS[i] < 0)
         maleMS[i] = 0;
   } // end of i

   tmeanms = Mean(maleMS,Nmales-1);

   for (i = 0; i < Nmales; i++)
   {
       maleMS[i] = maleMS[i] * (meanMS/tmeanms);
       if (maleMS[i] - floor(maleMS[i]) < 0.5)
          maleMS[i] = floor(maleMS[i]);
       else
          maleMS[i] = floor(maleMS[i]) + 1;
   } // end of i

   for (i = 0; i < Nmales; i++)
   {
       maleRS[i] = randnorm(meanRS,SDwithinMSclass) + ((maleMS[i]-meanMS) * increaseRSperMate);
       if (maleMS[i] == 0)
          maleRS[i] = 0;
       if (maleRS[i] < maleMS[i])
          maleRS[i] = maleMS[i];
   } // end of i

   tmeanrs = Mean(maleRS,Nmales-1);

   for (i = 0; i < Nmales; i++)
   {
     maleRS[i] = maleRS[i] * (meanRS/tmeanrs);
     if (maleRS[i] - floor(maleRS[i]) < 0.5)
          maleRS[i] = floor(maleRS[i]);
     else
          maleRS[i] = floor(maleRS[i]) + 1;

     if (maleRS[i] < maleMS[i])
          maleRS[i] = maleMS[i];
   } // end of i

   Nclutches = 0;
   for (i = 0; i < Nmales; i++)
      Nclutches = Nclutches + maleMS[i];

   double *clutchSize = new double[Nclutches];
   int *clutchFather = new int[Nclutches];
   bool *clutchSampled = new bool[Nclutches];
   double tempNclutch[100];

   counter = 0;
   for (i = 0; i < Nmales; i++)
   {
    if (maleMS[i] > 0)
    {
     tempint1 = maleMS[i];
     tempdub2 = 0;
     tempdub1 = maleRS[i]/maleMS[i];
     tempdub1 = floor(tempdub1);

     for (j = 0; j < tempint1; j++)
     {
       tempNclutch[j] = tempdub1;
       tempdub2 = tempdub2 + tempdub1;
     }

     tempdub1 = maleRS[i];
     tempNclutch[0] = tempNclutch[0] + (tempdub1 - tempdub2);

     for (j = 0; j < tempint1; j++)
     {
        clutchFather[counter] = i;
        clutchSize[counter] = tempNclutch[j];
        counter++;
     }

    } // end of if maleMS[i] > 0
   }  // end of i

 if (!globalBigRun)
 {
   for (i = 0; i < Nmales; i++)
   {
       tempString = FloatToStrF(maleMS[i],ffFixed,6,6) + "\t";
       tempString = tempString + FloatToStrF(maleRS[i],ffFixed,6,6);
       RichEdit1->Lines->Add(tempString);
   }
 }
 if (!globalBigRun)
 {
   RichEdit1->Lines->Add("Clutches:");

   for (i = 0; i < Nclutches; i++)
   {
     tempString = IntToStr(clutchFather[i]) + "\t" + FloatToStr(clutchSize[i]);
     RichEdit1->Lines->Add(tempString);
   }
 }
   tempdub1 = Nclutches;
   tempdub2 = tempdub1*propClutchesSampled;
   if (tempdub2 - floor(tempdub2) < 0.5)
        tempdub2 = floor(tempdub2);
   else
        tempdub2 = floor(tempdub2) + 1;
   NclutchesToSample = tempdub2;

   if (NclutchesToSample > Nclutches)
      NclutchesToSample = Nclutches;

   for (i = 0; i < Nclutches; i++)
       clutchSampled[i] = false;

   for (i = 0; i < NclutchesToSample; i++)
   {
       tempint1 = randnum(Nclutches);
       while (clutchSampled[tempint1] == true)
           tempint1 = randnum(Nclutches);
       clutchSampled[tempint1] = true;
   } // end of i

   // calculate ms and rs from sample of clutches

   for (i = 0; i < Nmales; i++)
   {
      maleMSinsample[i] = 0;
      maleRSinsample[i] = 0;
   }

   for (i = 0; i < Nclutches; i++)
   {
       if (clutchSampled[i] == true)
       {
          tempint1 = clutchFather[i];
          maleMSinsample[tempint1]++;
          maleRSinsample[tempint1] = maleRSinsample[tempint1] + clutchSize[i];
       }
   } // end of i
 if (!globalBigRun)
 {
   RichEdit1->Lines->Add("Clutches:\t\tmale\tsize\tsampled");
   for (i = 0; i < Nclutches; i++)
   {
     tempString = "Clutch\t" + IntToStr(i) + "\t" +  IntToStr(clutchFather[i]) + "\t" +
                   FloatToStr(clutchSize[i]) + "\t" + BoolToStr(clutchSampled[i],true);
     RichEdit1->Lines->Add(tempString);
   }

   RichEdit1->Lines->Add("Male:\t\tsMS\tsRS");

   for (i = 0; i < Nmales; i++)
   {
     tempString = "Male:\t" + IntToStr(i) + "\t" + FloatToStr(maleMSinsample[i]) + "\t" + FloatToStr(maleRSinsample[i]);
     RichEdit1->Lines->Add(tempString);
   } // end of i
 }

   double realMeanMS, realMeanRS, realStdDevMS, realStdDevRS, realI, realIs, realBG;
   double sampMeanMS, sampMeanRS, sampStdDevMS, sampStdDevRS, sampI, sampIs, sampBG;
   double covariance;
   int NtruncSamp;
   double * truncSampMS = new double[Nmales];
   double * truncSampRS = new double[Nmales];

   NtruncSamp = 0;
   for (i = 0; i < Nmales; i++)
   {
      if (maleMSinsample[i] > 0 && maleRSinsample[i] > 0)
      {
        truncSampMS[NtruncSamp] = maleMSinsample[i];
        truncSampRS[NtruncSamp] = maleRSinsample[i];
        NtruncSamp++;
      }
   } // end of i

 if (!globalBigRun)
 {
   RichEdit1->Lines->Add(" ");
   RichEdit1->Lines->Add("Sample of Males:");
   RichEdit1->Lines->Add("MS\tsRS");
   for (i = 0; i < NtruncSamp; i++)
   {
     tempString = FloatToStr(truncSampMS[i]) + "\t" + FloatToStr(truncSampRS[i]);
     RichEdit1->Lines->Add(tempString);
   } // end of i
 }


   realMeanMS = Mean(maleMS,Nmales-1);
   realMeanRS = Mean(maleRS,Nmales-1);
   realStdDevMS = StdDev(maleMS,Nmales-1);
   realStdDevRS = StdDev(maleRS,Nmales-1);
   covariance = 0;
   for (i = 0; i < Nmales; i++)
   {
       covariance = covariance + (maleMS[i] - realMeanMS) * (maleRS[i] - realMeanRS);
   } // end of i
   tempdub1 = Nmales-1;
   covariance = covariance/tempdub1;

   realBG = covariance/((realStdDevMS)*(realStdDevMS));
   realI = (realStdDevRS * realStdDevRS)/(realMeanRS * realMeanRS);
   realIs = (realStdDevMS * realStdDevMS)/(realMeanMS * realMeanMS);

 if (!globalBigRun)
 {
   RichEdit1->Lines->Add(" ");
   tempString = "Real Mean MS:\t" + FloatToStr(realMeanMS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Real Mean RS:\t" + FloatToStr(realMeanRS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Real StDv MS:\t" + FloatToStr(realStdDevMS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Real StDv RS:\t" + FloatToStr(realStdDevRS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Real I      :\t" + FloatToStr(realI);
   RichEdit1->Lines->Add(tempString);
   tempString = "Real Is     :\t" + FloatToStr(realIs);
   RichEdit1->Lines->Add(tempString);
   tempString = "Real BetaSS :\t" + FloatToStr(realBG);
   RichEdit1->Lines->Add(tempString);
 }

   sampMeanMS = Mean(truncSampMS,NtruncSamp-1);
   sampMeanRS = Mean(truncSampRS,NtruncSamp-1);
   sampStdDevMS = StdDev(truncSampMS,NtruncSamp-1);
   sampStdDevRS = StdDev(truncSampRS,NtruncSamp-1);
   covariance = 0;
   for (i = 0; i < NtruncSamp; i++)
   {
       covariance = covariance + (truncSampMS[i] - sampMeanMS) * (truncSampRS[i] - sampMeanRS);
   } // end of i
   tempdub1 = NtruncSamp-1;
   covariance = covariance/tempdub1;

   sampBG = covariance/((sampStdDevMS)*(sampStdDevMS));
   sampI = (sampStdDevRS * sampStdDevRS)/(sampMeanRS * sampMeanRS);
   sampIs = (sampStdDevMS * sampStdDevMS)/(sampMeanMS * sampMeanMS);

 if (!globalBigRun)
 {
   RichEdit1->Lines->Add(" ");
   tempString = "Samp Mean MS:\t" + FloatToStr(sampMeanMS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Samp Mean RS:\t" + FloatToStr(sampMeanRS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Samp StDv MS:\t" + FloatToStr(sampStdDevMS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Samp StDv RS:\t" + FloatToStr(sampStdDevRS);
   RichEdit1->Lines->Add(tempString);
   tempString = "Samp I      :\t" + FloatToStr(sampI);
   RichEdit1->Lines->Add(tempString);
   tempString = "Samp Is     :\t" + FloatToStr(sampIs);
   RichEdit1->Lines->Add(tempString);
   tempString = "Samp BetaSS :\t" + FloatToStr(sampBG);
   RichEdit1->Lines->Add(tempString);
 }

   globalFemaleMeanMS = realMeanMS;
   globalFemaleMeanRS = realMeanRS;
   globalSexRatio = 0.5;
   globalEstimatedNumberMales = Nmales;


   globalNmaleData = NtruncSamp;
   globalClutchesSampled = 0;
   for (i = 0; i < NtruncSamp; i++)
   {
     globalMaleMS[i] = truncSampMS[i];
     globalMaleRS[i] = truncSampRS[i];
     globalClutchesSampled = globalClutchesSampled + globalMaleMS[i];
   }

    globalResultsRealMeanMS = realMeanMS;
    globalResultsRealMeanRS = realMeanRS;
    globalResultsRealSDMS = realStdDevMS;
    globalResultsRealSDRS = realStdDevRS;
    globalResultsRealI = realI;
    globalRestulsRealIs = realIs;
    globalResultsRealBetaSS = realBG;

    globalResultsSampleMeanMS = sampMeanMS;
    globalResultsSampleMeanRS = sampMeanRS;
    globalResultsSampleSDMS = sampStdDevMS;
    globalResultsSampleSDRS = sampStdDevRS;
    globalResultsSampleI = sampI;
    globalRestulsSampleIs = sampIs;
    globalResultsSampleBetaSS = sampBG;

    globalFemaleMeanMS = realMeanMS;
    globalFemaleMeanRS = realMeanRS;
    globalSexRatio = 0.5;


    delete[] maleMS;
    delete[] maleRS;
    delete[] clutchSize;
    delete[] clutchFather;
    delete[] clutchSampled;
    delete[] maleMSinsample;
    delete[] maleRSinsample;
    delete[] truncSampMS;
    delete[] truncSampRS;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::BigRunExecute(TObject *Sender)
{
   int BRi;
   AnsiString tStr;

   RichEdit1->Lines->Clear();
   globalBigRun = true;

   globalmeanMS = 2.5;
   globalstddevMS = 1.0;

   globalmeanRSsim = 500;
   globalSDwithinMSclass = 50;
   globalincreaseRSperMate = 0;

   globalNmales = 300;

   globalpropClutchesSampled = 0.20;

   tStr = "pNmal\tpAveMS\tpSDms\tpRSave\tpSDrs\tpRSperM\tp%samp";
   tStr = tStr + "\trAveMS\trAveRS\trSDms\trSDrs\trIs\trI\trBG\t";
   tStr = tStr + "sAveMS\tsAveRS\tsSDms\tsSDrs\tsIs\tsI\tsBG\t";
   tStr = tStr + "eSDms\teSDrs\teIs\teI\teBG\teBGno0s";
   RichEdit1->Lines->Add(tStr);

   for (BRi = 0; BRi < 30; BRi++)
   {
      globalEstimatedNumberMales = 300;
      SimulateClutches->Execute();
      globalEstimatedNumberMales = 400;
      if (globalNmaleData > globalEstimatedNumberMales)
                globalEstimatedNumberMales = globalNmaleData + 1;  // you can't have data for more males than you estimate in the population
      MatingDistribution->Execute();
      Main->Execute();

      tStr = FloatToStrF(globalNmales,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalmeanMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalstddevMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalmeanRSsim,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalSDwithinMSclass,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalincreaseRSperMate,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalpropClutchesSampled,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsRealMeanMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsRealMeanRS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsRealSDMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsRealSDRS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalRestulsRealIs,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsRealI,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsRealBetaSS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsSampleMeanMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsSampleMeanRS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsSampleSDMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsSampleSDRS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalRestulsSampleIs,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsSampleI,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsSampleBetaSS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsEstSDMS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsEstSDRS,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsEstIs,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsEstI,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsEstBG,ffFixed,8,3) + "\t";
      tStr = tStr + FloatToStrF(globalResultsEstBGnz,ffFixed,8,3) + "\t";

      RichEdit1->Lines->Add(tStr);
   }


   globalBigRun = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BootstrapMSExecute(TObject *Sender)
{
	 DisableUI->Execute();

    // bootstrap both ms only
      int i, j, k;
      int iBootReps, boot;
      int rndi;
      double CovMSRS;
      double dub1, dub2;
      AnsiString tStr;

      double meanMS, MSMlower, MSMupper, MSMlower90, MSMupper90;
      double meanRS, RSMlower, RSMupper, RSMlower90, RSMupper90;
      double varMS, MSVlower, MSVupper, MSVlower90, MSVupper90;
      double varRS, RSVlower, RSVupper, RSVlower90, RSVupper90;
      double pointIms, Imslower, Imsupper, Imslower90, Imsupper90;
      double pointIrs, Irslower, Irsupper, Irslower90, Irsupper90;
      double pointBG, BGlower, BGupper, BGlower90, BGupper90;
      double bootAveMeanMS, bootAveMeanRS, bootAveSDMS, bootAveSDRS;
      double bootAveI, bootAveIs, bootAveBG, bootAveBGnz, bootAveEstSD;

      // First we need a master list of the data, so we can reset it back every rep

      iBootReps = globalBootReps;

      int NmaleDataInt;

      NmaleDataInt = globalNmaleData;

      double *dataMasterMS = new double[NmaleDataInt];
      double *dataMasterRS = new double[NmaleDataInt];

      for (i = 0; i < NmaleDataInt; i++)
      {
         dataMasterMS[i] = globalMaleMS[i];
         dataMasterRS[i] = globalMaleRS[i];
      }

      double *bootMaleMS = new double[NmaleDataInt];
      double *bootMaleRS = new double[NmaleDataInt];

      double *bootI = new double[iBootReps];
      double *bootIs = new double[iBootReps];
      double *bootBateGrad = new double[iBootReps];
      double *bootMeanMS = new double[iBootReps];
      double *bootMeanRS = new double[iBootReps];
      double *bootStDevMS = new double[iBootReps];
      double *bootStDevRS = new double[iBootReps];
      double *bootBGnoZ = new double[iBootReps];
      double *bootSDforEst = new double[iBootReps];

      RichEdit1->Clear();
      tStr = "BSrep\tmeanMS\tstdevMS\tIs(ms)\tSDMSest";
      RichEdit1->Lines->Add(tStr);

	  int tenpercentofreps;
	  tenpercentofreps = iBootReps/10;

	  globalBigRun = true;

	  Panel1->Show();
	  ProgressBar1->Max = iBootReps;
	  ProgressBar1->Position = 0;

      for (boot = 0; boot < iBootReps; boot++)
	  {

        // set the data to the original values
        for (i = 0; i < NmaleDataInt; i++)
        {
         globalMaleMS[i] = dataMasterMS[i];
         globalMaleRS[i] = dataMasterRS[i];
        }

        // sample with replacement
         for (i = 0; i < NmaleDataInt; i++)
         {
            rndi = randnum(NmaleDataInt);
            globalMaleMS[i] = dataMasterMS[rndi];
            globalMaleRS[i] = dataMasterRS[rndi];
         } // end of i


         MatingDistribution->Execute();

         // results of estimation procedures

         bootIs[boot] = globalResultsEstIs;
         bootMeanMS[boot] = globalCalculatedMaleMSmean;
         bootStDevMS[boot] = globalResultsEstSDMS;
         bootSDforEst[boot] = globalEstimationSDMS;

         // output the results of each bootstrap replicate

         tStr = IntToStr(boot+1) + "\t" + FloatToStrF(bootMeanMS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootStDevMS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootIs[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSDforEst[boot],ffFixed,8,2);

         RichEdit1->Lines->Add(tStr);

		if (LogFileName != "NoFile" && CheckBox1->Checked && (boot+1) % tenpercentofreps == 0) {
		   RichEdit1->Lines->SaveToFile(LogFileName + IntToStr(boot+1) + "bootstrapsComplete.txt");
		}

		ProgressBar1->Position++;

      } // end of boot

      // Calculate Point Estimates of the Statistics

        bootAveMeanMS = Mean(bootMeanMS, iBootReps-1);
        bootAveSDMS = Mean(bootStDevMS, iBootReps-1);
        bootAveIs = Mean(bootIs, iBootReps-1);
        bootAveEstSD = Mean(bootSDforEst, iBootReps-1);

      // Sort bootstrap lists for each Statistic

      double *bootSortList = new double[iBootReps+1];
      int BSLsize;

      BSLsize = 1;
      bootSortList[0] = bootMeanMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootIs[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootIs[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootIs[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootIs[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootStDevMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootStDevMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootStDevMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootStDevMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSDforEst[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSDforEst[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSDforEst[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSDforEst[i] = bootSortList[i];

       // output the results of each sorted list

     // RichEdit1->Lines->Add("Sorted:");
     // for (i = 0; i < iBootReps; i++)
     // {
     //    tStr = IntToStr(i+1) + "\t" + FloatToStrF(bootMeanMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootMeanRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootIs[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootI[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootBateGrad[i],ffFixed,8,2);
     //    RichEdit1->Lines->Add(tStr);
     // } // end of i

      // determine BS confidence intervals

      int lowerCIindex, upperCIindex;
      int lowerCIindex90, upperCIindex90;
      double realCI95;
      double realCI90;

     // 95 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.025;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex = i;
      upperCIindex = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI95 = dub1;

    // 90 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.05;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex90 = i;
      upperCIindex90 = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI90 = dub1;

      tStr = " ";
      RichEdit1->Lines->Add(tStr);
      tStr = "Variable       \tEstimate\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI95,ffFixed,4,1) + "%)";
      tStr = tStr + "\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI90,ffFixed,4,1) + "%)";
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanMS         \t";
      tStr = tStr + FloatToStrF(bootAveMeanMS,ffFixed,8,2) + "\t";
      MSMlower = bootMeanMS[lowerCIindex];
      MSMupper = bootMeanMS[upperCIindex];
      MSMlower90 = bootMeanMS[lowerCIindex90];
      MSMupper90 = bootMeanMS[upperCIindex90];
      tStr = tStr + FloatToStrF(MSMlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSMupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(MSMlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSMupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "Std.Dev.MS     \t";
      tStr = tStr + FloatToStrF(bootAveSDMS,ffFixed,8,2) + "\t";
      MSVlower = bootStDevMS[lowerCIindex];
      MSVupper = bootStDevMS[upperCIindex];
      MSVlower90 = bootStDevMS[lowerCIindex90];
      MSVupper90 = bootStDevMS[upperCIindex90];
      tStr = tStr + FloatToStrF(MSVlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSVupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(MSVlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSVupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "OppSexSel(Is)  \t";
      tStr = tStr + FloatToStrF(bootAveIs,ffFixed,8,2) + "\t";
      Imslower = bootIs[lowerCIindex];
      Imsupper = bootIs[upperCIindex];
      Imslower90 = bootIs[lowerCIindex90];
      Imsupper90 = bootIs[upperCIindex90];
      tStr = tStr + FloatToStrF(Imslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Imsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Imslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Imsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "SDmsForEstim.  \t";
      tStr = tStr + FloatToStrF(bootAveEstSD,ffFixed,8,2) + "\t";
      BGlower = bootSDforEst[lowerCIindex];
      BGupper = bootSDforEst[upperCIindex];
      BGlower90 = bootSDforEst[lowerCIindex90];
      BGupper90 = bootSDforEst[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      // make sure the data are set back to their original values
      for (i = 0; i < NmaleDataInt; i++)
      {
         globalMaleMS[i] = dataMasterMS[i];
         globalMaleRS[i] = dataMasterRS[i];
      }

      globalBigRun = false;
	  globalEstimationSDMS = bootAveEstSD;

	  if (LogFileName != "NoFile" && CheckBox1->Checked) {
		   RichEdit1->Lines->SaveToFile(LogFileName + "Results.txt");
	  }

	  EnableUI->Execute();

      delete[] bootMaleMS;
      delete[] bootMaleRS;
      delete[] bootI;
      delete[] bootIs;
      delete[] bootBateGrad;
      delete[] bootMeanMS;
      delete[] bootMeanRS;
      delete[] bootStDevMS;
      delete[] bootStDevRS;
      delete[] bootSortList;
      delete[] dataMasterMS;
      delete[] dataMasterRS;
      delete[] bootBGnoZ;
      delete[] bootSDforEst;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BootstrapAllExecute(TObject *Sender)
{
		DisableUI->Execute();

      // bootstrap both ms and bg estimation
      int i, j, k;
      int iBootReps, boot;
      int rndi;
      double CovMSRS;
      double dub1, dub2;
      AnsiString tStr;

      double meanMS, MSMlower, MSMupper, MSMlower90, MSMupper90;
      double meanRS, RSMlower, RSMupper, RSMlower90, RSMupper90;
      double varMS, MSVlower, MSVupper, MSVlower90, MSVupper90;
      double varRS, RSVlower, RSVupper, RSVlower90, RSVupper90;
      double pointIms, Imslower, Imsupper, Imslower90, Imsupper90;
      double pointIrs, Irslower, Irsupper, Irslower90, Irsupper90;
      double pointBG, BGlower, BGupper, BGlower90, BGupper90;
      double bootAveMeanMS, bootAveMeanRS, bootAveSDMS, bootAveSDRS;
      double bootAveI, bootAveIs, bootAveBG, bootAveBGnz, bootAveEstSD;
      double bootAvecorrMSRS, bootAveSigmaRS;
      double bootAveBGprime, bootAveSmax;
      double pointBGprime, BGprimelower, BGprimeupper, BGprimelower90, BGprimeupper90;
      double pointSmax, Smaxlower, Smaxupper, Smaxlower90, Smaxupper90;

      // First we need a master list of the data, so we can reset it back every rep

      iBootReps = globalBootReps;

      int NmaleDataInt;

      NmaleDataInt = globalNmaleData;

      double *dataMasterMS = new double[NmaleDataInt];
      double *dataMasterRS = new double[NmaleDataInt];

      for (i = 0; i < NmaleDataInt; i++)
      {
         dataMasterMS[i] = globalMaleMS[i];
         dataMasterRS[i] = globalMaleRS[i];
      }

      double *bootMaleMS = new double[NmaleDataInt];
      double *bootMaleRS = new double[NmaleDataInt];

      double *bootI = new double[iBootReps];
      double *bootIs = new double[iBootReps];
      double *bootBateGrad = new double[iBootReps];
      double *bootMeanMS = new double[iBootReps];
      double *bootMeanRS = new double[iBootReps];
      double *bootStDevMS = new double[iBootReps];
      double *bootStDevRS = new double[iBootReps];
      double *bootBGnoZ = new double[iBootReps];
      double *bootSDforEst = new double[iBootReps];
      double *bootcorrMSRS = new double[iBootReps];
      double *bootSigmaRS = new double[iBootReps];

      double *bootBGprime = new double[iBootReps];
      double *bootSmax = new double[iBootReps];

      RichEdit1->Clear();
      tStr = "BSrep\tmeanMS\tmeanRS\tstdevMS\tstdevRS\tIs(ms)\tI(rs)\tBateGr\tBGno0s\tBG'\tS'max\tSDMSest\tRS/MS\tSDrsParam";
      RichEdit1->Lines->Add(tStr);

	  int tenpercentofreps = iBootReps/10;

	  globalBigRun = true;

	  Panel1->Show();
	  ProgressBar1->Max = iBootReps;
	  ProgressBar1->Position = 0;

      for (boot = 0; boot < iBootReps; boot++)
	  {
        // set the data to the original values
		for (i = 0; i < NmaleDataInt; i++)
		{
         globalMaleMS[i] = dataMasterMS[i];
         globalMaleRS[i] = dataMasterRS[i];
		}

        // sample with replacement
         for (i = 0; i < NmaleDataInt; i++)
         {
            rndi = randnum(NmaleDataInt);
            globalMaleMS[i] = dataMasterMS[rndi];
            globalMaleRS[i] = dataMasterRS[rndi];
         } // end of i

         MatingDistribution->Execute();
         Main->Execute();

         // results of estimation procedures

         bootI[boot] = globalResultsEstI;
         bootIs[boot] = globalResultsEstIs;
         bootBateGrad[boot] = globalResultsEstBG;
         bootMeanMS[boot] = globalCalculatedMaleMSmean;
         bootMeanRS[boot] = globalCalculatedMaleRSmean;
         bootStDevMS[boot] = globalResultsEstSDMS;
         bootStDevRS[boot] = globalResultsEstSDRS;
         bootBGnoZ[boot] = globalResultsEstBGnz;
         bootSDforEst[boot] = globalEstimationSDMS;
         bootcorrMSRS[boot] = globalResultscorrMSRS;
         bootSigmaRS[boot] = globalResultsSigmaRS;
         bootBGprime[boot] = globalResultsBGprime;
         bootSmax[boot] = globalResultsSmax;

         // output the results of each bootstrap replicate

         tStr = IntToStr(boot+1) + "\t" + FloatToStrF(bootMeanMS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootMeanRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootStDevMS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootStDevRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootIs[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootI[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBateGrad[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBGnoZ[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBGprime[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSmax[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSDforEst[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootcorrMSRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSigmaRS[boot],ffFixed,8,2);

         RichEdit1->Lines->Add(tStr);

		 if (LogFileName != "NoFile" && CheckBox1->Checked && (boot+1) % tenpercentofreps == 0) {
		   RichEdit1->Lines->SaveToFile(LogFileName + IntToStr(boot+1) + "bootstrapsComplete.txt");
		}

		ProgressBar1->Position++;

      } // end of boot

      // Calculate Point Estimates of the Statistics

        bootAveMeanMS = Mean(bootMeanMS, iBootReps-1);
        bootAveMeanRS  = Mean(bootMeanRS, iBootReps-1);
        bootAveSDMS = Mean(bootStDevMS, iBootReps-1);
        bootAveSDRS = Mean(bootStDevRS, iBootReps-1);
        bootAveIs = Mean(bootIs, iBootReps-1);
        bootAveI  = Mean(bootI, iBootReps-1);
        bootAveBG = Mean(bootBateGrad, iBootReps-1);
        bootAveBGnz = Mean(bootBGnoZ, iBootReps-1);
        bootAveEstSD = Mean(bootSDforEst, iBootReps-1);
        bootAvecorrMSRS = Mean(bootcorrMSRS, iBootReps-1);
        bootAveSigmaRS = Mean(bootSigmaRS, iBootReps-1);
        bootAveBGprime = Mean(bootBGprime, iBootReps-1);
        bootAveSmax = Mean(bootSmax, iBootReps-1);


      // Sort bootstrap lists for each Statistic

      double *bootSortList = new double[iBootReps+1];
      int BSLsize;

      BSLsize = 1;
      bootSortList[0] = bootMeanMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootMeanRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootI[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootI[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootI[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootI[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootIs[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootIs[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootIs[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootIs[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBateGrad[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBateGrad[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBateGrad[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBateGrad[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootStDevMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootStDevMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootStDevMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootStDevMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootStDevRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootStDevRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootStDevRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootStDevRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBGnoZ[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBGnoZ[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBGnoZ[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBGnoZ[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSDforEst[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSDforEst[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSDforEst[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSDforEst[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootcorrMSRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootcorrMSRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootcorrMSRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootcorrMSRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSigmaRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSigmaRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSigmaRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSigmaRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBGprime[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBGprime[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBGprime[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBGprime[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSmax[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSmax[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSmax[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSmax[i] = bootSortList[i];

       // output the results of each sorted list

     // RichEdit1->Lines->Add("Sorted:");
     // for (i = 0; i < iBootReps; i++)
     // {
     //    tStr = IntToStr(i+1) + "\t" + FloatToStrF(bootMeanMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootMeanRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootIs[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootI[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootBateGrad[i],ffFixed,8,2);
     //    RichEdit1->Lines->Add(tStr);
     // } // end of i

      // determine BS confidence intervals

      int lowerCIindex, upperCIindex;
      int lowerCIindex90, upperCIindex90;
      double realCI95;
      double realCI90;

     // 95 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.025;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex = i;
      upperCIindex = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI95 = dub1;

    // 90 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.05;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex90 = i;
      upperCIindex90 = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI90 = dub1;

      tStr = " ";
      RichEdit1->Lines->Add(tStr);
      tStr = "Variable       \tEstimate\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI95,ffFixed,4,1) + "%)";
      tStr = tStr + "\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI90,ffFixed,4,1) + "%)";
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanMS         \t";
      tStr = tStr + FloatToStrF(bootAveMeanMS,ffFixed,8,2) + "\t";
      MSMlower = bootMeanMS[lowerCIindex];
      MSMupper = bootMeanMS[upperCIindex];
      MSMlower90 = bootMeanMS[lowerCIindex90];
      MSMupper90 = bootMeanMS[upperCIindex90];
      tStr = tStr + FloatToStrF(MSMlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSMupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(MSMlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSMupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanRS         \t";
      tStr = tStr + FloatToStrF(bootAveMeanRS,ffFixed,8,2) + "\t";
      RSMlower = bootMeanRS[lowerCIindex];
      RSMupper = bootMeanRS[upperCIindex];
      RSMlower90 = bootMeanRS[lowerCIindex90];
      RSMupper90 = bootMeanRS[upperCIindex90];
      tStr = tStr + FloatToStrF(RSMlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSMupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(RSMlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSMupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "Std.Dev.MS     \t";
      tStr = tStr + FloatToStrF(bootAveSDMS,ffFixed,8,2) + "\t";
      MSVlower = bootStDevMS[lowerCIindex];
      MSVupper = bootStDevMS[upperCIindex];
      MSVlower90 = bootStDevMS[lowerCIindex90];
      MSVupper90 = bootStDevMS[upperCIindex90];
      tStr = tStr + FloatToStrF(MSVlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSVupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(MSVlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSVupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "Std.Dev.RS     \t";
      tStr = tStr + FloatToStrF(bootAveSDRS,ffFixed,8,2) + "\t";
      RSVlower = bootStDevRS[lowerCIindex];
      RSVupper = bootStDevRS[upperCIindex];
      RSVlower90 = bootStDevRS[lowerCIindex90];
      RSVupper90 = bootStDevRS[upperCIindex90];
      tStr = tStr + FloatToStrF(RSVlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSVupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(RSVlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSVupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "OppSexSel(Is)  \t";
      tStr = tStr + FloatToStrF(bootAveIs,ffFixed,8,2) + "\t";
      Imslower = bootIs[lowerCIindex];
      Imsupper = bootIs[upperCIindex];
      Imslower90 = bootIs[lowerCIindex90];
      Imsupper90 = bootIs[upperCIindex90];
      tStr = tStr + FloatToStrF(Imslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Imsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Imslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Imsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "OppSelec(I)    \t";
      tStr = tStr + FloatToStrF(bootAveI,ffFixed,8,2) + "\t";
      Irslower = bootI[lowerCIindex];
      Irsupper = bootI[upperCIindex];
      Irslower90 = bootI[lowerCIindex90];
      Irsupper90 = bootI[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "BatemanGradient\t";
      tStr = tStr + FloatToStrF(bootAveBG,ffFixed,8,2) + "\t";
      BGlower = bootBateGrad[lowerCIindex];
      BGupper = bootBateGrad[upperCIindex];
      BGlower90 = bootBateGrad[lowerCIindex90];
      BGupper90 = bootBateGrad[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "BateGrad(no0s) \t";
      tStr = tStr + FloatToStrF(bootAveBGnz,ffFixed,8,2) + "\t";
      Irslower = bootBGnoZ[lowerCIindex];
      Irsupper = bootBGnoZ[upperCIindex];
      Irslower90 = bootBGnoZ[lowerCIindex90];
      Irsupper90 = bootBGnoZ[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "Standardized BG\t";
      tStr = tStr + FloatToStrF(bootAveBGprime,ffFixed,8,2) + "\t";
      Irslower = bootBGprime[lowerCIindex];
      Irsupper = bootBGprime[upperCIindex];
      Irslower90 = bootBGprime[lowerCIindex90];
      Irsupper90 = bootBGprime[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "S'max            \t";
      tStr = tStr + FloatToStrF(bootAveSmax,ffFixed,8,2) + "\t";
      Irslower = bootSmax[lowerCIindex];
      Irsupper = bootSmax[upperCIindex];
      Irslower90 = bootSmax[lowerCIindex90];
      Irsupper90 = bootSmax[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "SDmsForEstim.  \t";
      tStr = tStr + FloatToStrF(bootAveEstSD,ffFixed,8,2) + "\t";
      BGlower = bootSDforEst[lowerCIindex];
      BGupper = bootSDforEst[upperCIindex];
      BGlower90 = bootSDforEst[lowerCIindex90];
      BGupper90 = bootSDforEst[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "RS incr./mate \t";
      tStr = tStr + FloatToStrF(bootAvecorrMSRS,ffFixed,8,2) + "\t";
      BGlower = bootcorrMSRS[lowerCIindex];
      BGupper = bootcorrMSRS[upperCIindex];
      BGlower90 = bootcorrMSRS[lowerCIindex90];
      BGupper90 = bootcorrMSRS[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "StDev RS param\t";
      tStr = tStr + FloatToStrF(bootAveSigmaRS,ffFixed,8,2) + "\t";
      BGlower = bootSigmaRS[lowerCIindex];
      BGupper = bootSigmaRS[upperCIindex];
      BGlower90 = bootSigmaRS[lowerCIindex90];
      BGupper90 = bootSigmaRS[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      // make sure the data are set back to their original values
      for (i = 0; i < NmaleDataInt; i++)
      {
         globalMaleMS[i] = dataMasterMS[i];
         globalMaleRS[i] = dataMasterRS[i];
      }

      globalBigRun = false;
      globalEstimationSDMS = bootAveEstSD;
      globalcorrMSRS = bootAvecorrMSRS;
	  globalSigmaRS = bootAveSigmaRS;

	  if (LogFileName != "NoFile" && CheckBox1->Checked) {
		   RichEdit1->Lines->SaveToFile(LogFileName + "Results.txt");
	  }

	  EnableUI->Execute();

      delete[] bootMaleMS;
      delete[] bootMaleRS;
      delete[] bootI;
      delete[] bootIs;
      delete[] bootBateGrad;
      delete[] bootMeanMS;
      delete[] bootMeanRS;
      delete[] bootStDevMS;
      delete[] bootStDevRS;
      delete[] bootSortList;
      delete[] dataMasterMS;
      delete[] dataMasterRS;
      delete[] bootBGnoZ;
      delete[] bootSDforEst;
      delete[] bootcorrMSRS;
      delete[] bootSigmaRS;
      delete[] bootBGprime;
      delete[] bootSmax;


}
//---------------------------------------------------------------------------

void __fastcall TForm1::BootstrapBGExecute(TObject *Sender)
{
		DisableUI->Execute();

	  // bootstrap just bg estimation
      int i, j, k;
      int iBootReps, boot;
      int rndi;
      double CovMSRS;
      double dub1, dub2;
      AnsiString tStr;

      double meanMS, MSMlower, MSMupper, MSMlower90, MSMupper90;
      double meanRS, RSMlower, RSMupper, RSMlower90, RSMupper90;
      double varMS, MSVlower, MSVupper, MSVlower90, MSVupper90;
      double varRS, RSVlower, RSVupper, RSVlower90, RSVupper90;
      double pointIms, Imslower, Imsupper, Imslower90, Imsupper90;
      double pointIrs, Irslower, Irsupper, Irslower90, Irsupper90;
      double pointBG, BGlower, BGupper, BGlower90, BGupper90;
      double bootAveMeanMS, bootAveMeanRS, bootAveSDMS, bootAveSDRS;
      double bootAveI, bootAveIs, bootAveBG, bootAveBGnz, bootAveEstSD;
      double bootAvecorrMSRS, bootAveSigmaRS;
      double pointBGprime, BGprimelower, BGprimeupper, BGprimelower90, BGprimeupper90;
      double pointSmax, Smaxupper, Smaxlower, Smaxupper90, Smaxlower90;
      double bootAveSmax, bootAveBGprime;

      // First we need a master list of the data, so we can reset it back every rep

      iBootReps = globalBootReps;

      int NmaleDataInt;

      NmaleDataInt = globalNmaleData;

      double *dataMasterMS = new double[NmaleDataInt];
      double *dataMasterRS = new double[NmaleDataInt];

      for (i = 0; i < NmaleDataInt; i++)
      {
         dataMasterMS[i] = globalMaleMS[i];
         dataMasterRS[i] = globalMaleRS[i];
      }

      double *bootMaleMS = new double[NmaleDataInt];
      double *bootMaleRS = new double[NmaleDataInt];

      double *bootI = new double[iBootReps];
      double *bootIs = new double[iBootReps];
      double *bootBateGrad = new double[iBootReps];
      double *bootMeanMS = new double[iBootReps];
      double *bootMeanRS = new double[iBootReps];
      double *bootStDevMS = new double[iBootReps];
      double *bootStDevRS = new double[iBootReps];
      double *bootBGnoZ = new double[iBootReps];
      double *bootSDforEst = new double[iBootReps];
      double *bootcorrMSRS = new double[iBootReps];
      double *bootSigmaRS = new double[iBootReps];
      double *bootBGprime = new double[iBootReps];
      double *bootSmax = new double[iBootReps];

      RichEdit1->Clear();
      tStr = "BSrep\tmeanMS\tmeanRS\tstdevRS\tI(rs)\tBateGr\tBGno0s\tBG'\tS'max\tRS/MS\tSDrsParam";
      RichEdit1->Lines->Add(tStr);

	  int tenpercentofreps = iBootReps/10;

	  globalBigRun = true;

	  Panel1->Show();
	  ProgressBar1->Max = iBootReps;
	  ProgressBar1->Position = 0;

      for (boot = 0; boot < iBootReps; boot++)
      {

        // set the data to the original values
        for (i = 0; i < NmaleDataInt; i++)
        {
         globalMaleMS[i] = dataMasterMS[i];
         globalMaleRS[i] = dataMasterRS[i];
        }

        // sample with replacement
         for (i = 0; i < NmaleDataInt; i++)
         {
            rndi = randnum(NmaleDataInt);
            globalMaleMS[i] = dataMasterMS[rndi];
            globalMaleRS[i] = dataMasterRS[rndi];
         } // end of i

         Main->Execute();

         // results of estimation procedures

         bootI[boot] = globalResultsEstI;
         bootIs[boot] = globalResultsEstIs;
         bootBateGrad[boot] = globalResultsEstBG;
         bootMeanMS[boot] = globalCalculatedMaleMSmean;
         bootMeanRS[boot] = globalCalculatedMaleRSmean;
         bootStDevMS[boot] = globalResultsEstSDMS;
         bootStDevRS[boot] = globalResultsEstSDRS;
         bootBGnoZ[boot] = globalResultsEstBGnz;
         bootSDforEst[boot] = globalEstimationSDMS;
         bootcorrMSRS[boot] = globalResultscorrMSRS;
         bootSigmaRS[boot] = globalResultsSigmaRS;
         bootBGprime[boot] = globalResultsBGprime;
         bootSmax[boot] = globalResultsSmax;

         // output the results of each bootstrap replicate

         tStr = IntToStr(boot+1) + "\t" + FloatToStrF(bootMeanMS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootMeanRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootStDevRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootI[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBateGrad[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBGnoZ[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootBGprime[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSmax[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootcorrMSRS[boot],ffFixed,8,2) + "\t" +
                FloatToStrF(bootSigmaRS[boot],ffFixed,8,2);

         RichEdit1->Lines->Add(tStr);

		if (LogFileName != "NoFile" && CheckBox1->Checked && (boot+1) % tenpercentofreps == 0) {
		   RichEdit1->Lines->SaveToFile(LogFileName + IntToStr(boot+1) + "bootstrapsComplete.txt");
		}

		ProgressBar1->Position++;

      } // end of boot

      // Calculate Point Estimates of the Statistics

        bootAveMeanMS = Mean(bootMeanMS, iBootReps-1);
        bootAveMeanRS  = Mean(bootMeanRS, iBootReps-1);
        bootAveSDMS = Mean(bootStDevMS, iBootReps-1);
        bootAveSDRS = Mean(bootStDevRS, iBootReps-1);
        bootAveIs = Mean(bootIs, iBootReps-1);
        bootAveI  = Mean(bootI, iBootReps-1);
        bootAveBG = Mean(bootBateGrad, iBootReps-1);
        bootAveBGnz = Mean(bootBGnoZ, iBootReps-1);
        bootAveEstSD = Mean(bootSDforEst, iBootReps-1);
        bootAvecorrMSRS = Mean(bootcorrMSRS, iBootReps-1);
        bootAveSigmaRS = Mean(bootSigmaRS, iBootReps-1);
        bootAveBGprime = Mean(bootBGprime, iBootReps-1);
        bootAveSmax = Mean(bootSmax, iBootReps-1);

      // Sort bootstrap lists for each Statistic

      double *bootSortList = new double[iBootReps+1];
      int BSLsize;

      BSLsize = 1;
      bootSortList[0] = bootMeanMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootMeanRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootMeanRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootMeanRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootMeanRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootI[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootI[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootI[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootI[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootIs[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootIs[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootIs[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootIs[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBateGrad[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBateGrad[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBateGrad[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBateGrad[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootStDevMS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootStDevMS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootStDevMS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootStDevMS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootStDevRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootStDevRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootStDevRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootStDevRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBGnoZ[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBGnoZ[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBGnoZ[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBGnoZ[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSDforEst[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSDforEst[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSDforEst[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSDforEst[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootcorrMSRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootcorrMSRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootcorrMSRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootcorrMSRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSigmaRS[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSigmaRS[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSigmaRS[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSigmaRS[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootBGprime[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootBGprime[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootBGprime[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootBGprime[i] = bootSortList[i];

      BSLsize = 1;
      bootSortList[0] = bootSmax[0];
      for (i = 1; i < iBootReps; i++)
      {
        j = 0;
        while (bootSmax[i] > bootSortList[j] && j < BSLsize)
          j++;
        for (k = BSLsize; k > j; k--)
           bootSortList[k] = bootSortList[k-1];
        bootSortList[j] = bootSmax[i];
        BSLsize++;
      } // end of i
      for (i = 0; i < iBootReps; i++)
          bootSmax[i] = bootSortList[i];

       // output the results of each sorted list

     // RichEdit1->Lines->Add("Sorted:");
     // for (i = 0; i < iBootReps; i++)
     // {
     //    tStr = IntToStr(i+1) + "\t" + FloatToStrF(bootMeanMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootMeanRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarMS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootVarRS[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootIs[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootI[i],ffFixed,8,2) + "\t" +
     //           FloatToStrF(bootBateGrad[i],ffFixed,8,2);
     //    RichEdit1->Lines->Add(tStr);
     // } // end of i

      // determine BS confidence intervals

      int lowerCIindex, upperCIindex;
      int lowerCIindex90, upperCIindex90;
      double realCI95;
      double realCI90;

     // 95 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.025;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex = i;
      upperCIindex = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI95 = dub1;

    // 90 percent indices
      dub1 = iBootReps;
      dub2 = dub1 * 0.05;
      dub2 = floor(dub2);
      i = dub2;
      j = iBootReps - i - 1;
      lowerCIindex90 = i;
      upperCIindex90 = j;

      dub1 = j - i + 1;
      dub2 = iBootReps;
      dub1 = dub1/dub2;
      dub1 = dub1*100;
      realCI90 = dub1;

      tStr = " ";
      RichEdit1->Lines->Add(tStr);
      tStr = "Variable       \tEstimate\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI95,ffFixed,4,1) + "%)";
      tStr = tStr + "\tLowerCI\tUpperCI\t(";
      tStr = tStr + FloatToStrF(realCI90,ffFixed,4,1) + "%)";
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanMS         \t";
      tStr = tStr + FloatToStrF(bootAveMeanMS,ffFixed,8,2) + "\t";
      MSMlower = bootMeanMS[lowerCIindex];
      MSMupper = bootMeanMS[upperCIindex];
      MSMlower90 = bootMeanMS[lowerCIindex90];
      MSMupper90 = bootMeanMS[upperCIindex90];
      tStr = tStr + FloatToStrF(MSMlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSMupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(MSMlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(MSMupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "MeanRS         \t";
      tStr = tStr + FloatToStrF(bootAveMeanRS,ffFixed,8,2) + "\t";
      RSMlower = bootMeanRS[lowerCIindex];
      RSMupper = bootMeanRS[upperCIindex];
      RSMlower90 = bootMeanRS[lowerCIindex90];
      RSMupper90 = bootMeanRS[upperCIindex90];
      tStr = tStr + FloatToStrF(RSMlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSMupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(RSMlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSMupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "Std.Dev.RS     \t";
      tStr = tStr + FloatToStrF(bootAveSDRS,ffFixed,8,2) + "\t";
      RSVlower = bootStDevRS[lowerCIindex];
      RSVupper = bootStDevRS[upperCIindex];
      RSVlower90 = bootStDevRS[lowerCIindex90];
      RSVupper90 = bootStDevRS[upperCIindex90];
      tStr = tStr + FloatToStrF(RSVlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSVupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(RSVlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(RSVupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "OppSelec(I)    \t";
      tStr = tStr + FloatToStrF(bootAveI,ffFixed,8,2) + "\t";
      Irslower = bootI[lowerCIindex];
      Irsupper = bootI[upperCIindex];
      Irslower90 = bootI[lowerCIindex90];
      Irsupper90 = bootI[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "BatemanGradient\t";
      tStr = tStr + FloatToStrF(bootAveBG,ffFixed,8,2) + "\t";
      BGlower = bootBateGrad[lowerCIindex];
      BGupper = bootBateGrad[upperCIindex];
      BGlower90 = bootBateGrad[lowerCIindex90];
      BGupper90 = bootBateGrad[upperCIindex90];
      tStr = tStr + FloatToStrF(BGlower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(BGlower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(BGupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "BateGrad(no0s) \t";
      tStr = tStr + FloatToStrF(bootAveBGnz,ffFixed,8,2) + "\t";
      Irslower = bootBGnoZ[lowerCIindex];
      Irsupper = bootBGnoZ[upperCIindex];
      Irslower90 = bootBGnoZ[lowerCIindex90];
      Irsupper90 = bootBGnoZ[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "Standardized BG\t";
      tStr = tStr + FloatToStrF(bootAveBGprime,ffFixed,8,2) + "\t";
      Irslower = bootBGprime[lowerCIindex];
      Irsupper = bootBGprime[upperCIindex];
      Irslower90 = bootBGprime[lowerCIindex90];
      Irsupper90 = bootBGprime[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      
      tStr = "S'max             \t";
      tStr = tStr + FloatToStrF(bootAveSmax,ffFixed,8,2) + "\t";
      Irslower = bootSmax[lowerCIindex];
      Irsupper = bootSmax[upperCIindex];
      Irslower90 = bootSmax[lowerCIindex90];
      Irsupper90 = bootSmax[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "RS increase/mate\t";
      tStr = tStr + FloatToStrF(bootAvecorrMSRS,ffFixed,8,2) + "\t";
      Irslower = bootcorrMSRS[lowerCIindex];
      Irsupper = bootcorrMSRS[upperCIindex];
      Irslower90 = bootcorrMSRS[lowerCIindex90];
      Irsupper90 = bootcorrMSRS[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);

      tStr = "StDev RS param \t";
      tStr = tStr + FloatToStrF(bootAveSigmaRS,ffFixed,8,2) + "\t";
      Irslower = bootSigmaRS[lowerCIindex];
      Irsupper = bootSigmaRS[upperCIindex];
      Irslower90 = bootSigmaRS[lowerCIindex90];
      Irsupper90 = bootSigmaRS[upperCIindex90];
      tStr = tStr + FloatToStrF(Irslower,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper,ffFixed,8,2) + "\t\t";
      tStr = tStr + FloatToStrF(Irslower90,ffFixed,8,2) + "\t";
      tStr = tStr + FloatToStrF(Irsupper90,ffFixed,8,2);
      RichEdit1->Lines->Add(tStr);


      // make sure the data are set back to their original values
      for (i = 0; i < NmaleDataInt; i++)
      {
         globalMaleMS[i] = dataMasterMS[i];
         globalMaleRS[i] = dataMasterRS[i];
      }

      globalBigRun = false;
      globalEstimationSDMS = bootAveEstSD;
      globalcorrMSRS = bootAvecorrMSRS;
	  globalSigmaRS = bootAveSigmaRS;

	  if (LogFileName != "NoFile" && CheckBox1->Checked) {
		   RichEdit1->Lines->SaveToFile(LogFileName + "Results.txt");
	  }

	  EnableUI->Execute();

      delete[] bootMaleMS;
      delete[] bootMaleRS;
      delete[] bootI;
      delete[] bootIs;
      delete[] bootBateGrad;
      delete[] bootMeanMS;
      delete[] bootMeanRS;
      delete[] bootStDevMS;
      delete[] bootStDevRS;
      delete[] bootSortList;
      delete[] dataMasterMS;
      delete[] dataMasterRS;
      delete[] bootBGnoZ;
      delete[] bootSDforEst;
      delete[] bootcorrMSRS;
      delete[] bootSigmaRS;
      delete[] bootBGprime;
      delete[] bootSmax;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
   if (CheckBox1->Checked) {
	if (SaveDialog1->Execute()) {
		LogFileName = SaveDialog1->FileName;
		StatusBar1->SimpleText = "Log File: " + LogFileName;
	}
   }
   else {
	   StatusBar1->SimpleText = "No Log File Selected";
	   LogFileName = "NoFile";
   }

   if (LogFileName == "NoFile") {
	  CheckBox1->Checked = false; 
   }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DisableUIExecute(TObject *Sender)
{
		File1->Enabled = false;
		Ru1->Enabled = false;
		CheckBox1->Enabled = false;
		ToolButton1->Enabled = false;
		ToolButton9->Enabled = false;
		ToolButton4->Enabled = false;
		ToolButton15->Enabled = false;
		ToolButton5->Enabled = false;
		ToolButton21->Enabled = false;
		ToolButton23->Enabled = false;
		ToolButton7->Enabled = false;
		ToolButton11->Enabled = false;
		ToolButton13->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::EnableUIExecute(TObject *Sender)
{
	   File1->Enabled = true;
		Ru1->Enabled = true;
		CheckBox1->Enabled = true;
		ToolButton1->Enabled = true;
		ToolButton9->Enabled = true;
		ToolButton4->Enabled = true;
		ToolButton15->Enabled = true;
		ToolButton5->Enabled = true;
		ToolButton21->Enabled = true;
		ToolButton23->Enabled = true;
		ToolButton7->Enabled = true;
		ToolButton11->Enabled = true;
		ToolButton13->Enabled = true;
}
//---------------------------------------------------------------------------

