//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm2::Button1Click(TObject *Sender)
{
        int PDi;
        AnsiString PDstr;
        double PDdub;
        int PDint;

        double ParamMaleMS;

        globalFemaleMeanMS = StrToFloat(Form2->Edit1->Text);
        globalFemaleMeanRS = StrToFloat(Form2->Edit2->Text);
        globalSexRatio = StrToFloat(Form2->Edit3->Text);
        globalEstimatedNumberMales = StrToFloat(Form2->Edit4->Text);
        globalClutchesSampled = StrToFloat(Form2->Edit5->Text);
        globalEstimationSDMS = StrToFloat(Form2->Edit6->Text);
        globalNrsIntervals = StrToFloat(Form2->Edit7->Text);
        globalEstReps = StrToFloat(Form2->Edit8->Text);
        globalBootReps = StrToFloat(Form2->Edit9->Text);
        globalMSstddevmax = StrToFloat(Form2->Edit11->Text);
        globalRSstddevmax = StrToFloat(Form2->Edit10->Text);
        globalNmsintervals = StrToFloat(Form2->Edit12->Text);
        globalRSperMatemax = StrToFloat(Form2->Edit13->Text);
        globalRSperMSintervals = StrToFloat(Form2->Edit14->Text);
        globalcorrMSRS = StrToFloat(Form2->Edit15->Text);
        globalSigmaRS = StrToFloat(Form2->Edit16->Text);

        ParamMaleMS = globalFemaleMeanMS * (1-globalSexRatio)/globalSexRatio;

        if (ParamMaleMS * globalEstimatedNumberMales > 20000)
            globalEstimatedNumberMales = floor(20000/ParamMaleMS);

        int RElength;

        RElength = RichEdit1->GetTextLen();
        RElength++;

        char *REbuff;
        double *NumberList;
        int NumberInList;
        int IndexLastNumber;

        REbuff = new char[RElength];
        NumberList = new double[RElength];

        for (PDi = 0; PDi < RElength; PDi++)
           NumberList[PDi] = 0;

        RichEdit1->GetTextBuf(REbuff,RElength);

        NumberInList = 0;

        for (PDi = 0; PDi < RElength; PDi++)
        {
          PDstr = REbuff[PDi];
          if (PDstr == "0" || PDstr == "1" || PDstr == "2" ||
              PDstr == "3" || PDstr == "4" || PDstr == "5" ||
              PDstr == "6" || PDstr == "7" || PDstr == "8" ||
              PDstr == "9")
              {
                PDdub = StrToFloat(PDstr);
                NumberList[NumberInList] = NumberList[NumberInList] * 10 + PDdub;
                IndexLastNumber = NumberInList;
              }
          if (PDstr == "\t" || PDstr == "," || PDstr == " " || PDstr == "\r")
              NumberInList++;
        } // end of PDi

        NumberInList = IndexLastNumber++;

        PDint = 0;
        for (PDi = 0; PDi < NumberInList; PDi = PDi + 2)
        {
           globalMaleMS[PDint] = NumberList[PDi];
           globalMaleRS[PDint] = NumberList[PDi+1];
           PDint++;
        }
        globalNmaleData = PDint;

        globalClutchesSampled = 0;
        for (PDi = 0; PDi < PDint; PDi++)
            globalClutchesSampled = globalClutchesSampled + globalMaleMS[PDi];

        if (ParamMaleMS * globalEstimatedNumberMales < globalClutchesSampled)
                globalEstimatedNumberMales = floor(globalClutchesSampled/ParamMaleMS) + 1;  // you have to estimate enough males to produce enough clutches

        if (globalNmaleData > globalEstimatedNumberMales)
                globalEstimatedNumberMales = globalNmaleData + 1;  // you can't have data for more males than you estimate in the population

        Form2->Close();

        delete[] REbuff;
        delete[] NumberList;

}
//---------------------------------------------------------------------------
