//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TMyThread : public TThread
{
private:
protected:
	void __fastcall Execute();
public:
	__fastcall TMyThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif
