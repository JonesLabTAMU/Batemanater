//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ToolWin.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <math.h>
#include <Math.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TRichEdit *RichEdit1;
        TStatusBar *StatusBar1;
        TToolBar *ToolBar1;
        TSaveDialog *SaveDialog1;
        TImageList *ImageList1;
        TActionList *ActionList1;
        TMainMenu *MainMenu1;
        TAction *Save;
        TToolButton *ToolButton1;
        TMenuItem *File1;
        TMenuItem *Save1;
        TAction *GenRands;
        TToolButton *ToolButton2;
        TAction *Main;
        TToolButton *ToolButton5;
        TMenuItem *Ru1;
        TMenuItem *RunMain1;
        TAction *BootStrap;
        TToolButton *ToolButton6;
        TToolButton *ToolButton7;
        TMenuItem *BootStrap1;
        TAction *LoadData;
        TToolButton *ToolButton8;
        TToolButton *ToolButton9;
        TMenuItem *LoadData1;
        TAction *ParseData;
        TPanel *Panel1;
        TButton *Button1;
        TProgressBar *ProgressBar1;
        TLabel *Label1;
        TAction *BootstrapData;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TMenuItem *BootstrapData1;
        TAction *SampleDistribution;
        TMenuItem *SampleDistribution1;
        TToolButton *ToolButton10;
        TToolButton *ToolButton11;
        TToolButton *ToolButton13;
        TToolButton *ToolButton14;
        TToolButton *ToolButton15;
        TAction *MatingDistribution;
        TAction *SimulateClutches;
        TAction *BigRun;
        TAction *BootstrapMS;
        TAction *BootstrapAll;
        TToolButton *ToolButton20;
        TToolButton *ToolButton21;
        TAction *BootstrapBG;
        TToolButton *ToolButton22;
        TToolButton *ToolButton23;
        TMenuItem *BootstrapBG1;
        TMenuItem *BootstrapAll1;
        TToolButton *ToolButton25;
	TCheckBox *CheckBox1;
	TToolButton *ToolButton12;
	TToolButton *ToolButton16;
	TAction *DisableUI;
	TAction *EnableUI;
        void __fastcall SaveExecute(TObject *Sender);
        void __fastcall GenRandsExecute(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall MainExecute(TObject *Sender);
        void __fastcall LoadDataExecute(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall BootStrapExecute(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall BootstrapDataExecute(TObject *Sender);
        void __fastcall SampleDistributionExecute(TObject *Sender);
        void __fastcall ToolButton13Click(TObject *Sender);
        void __fastcall MatingDistributionExecute(TObject *Sender);
        void __fastcall SimulateClutchesExecute(TObject *Sender);
        void __fastcall BigRunExecute(TObject *Sender);
        void __fastcall BootstrapMSExecute(TObject *Sender);
        void __fastcall BootstrapAllExecute(TObject *Sender);
        void __fastcall BootstrapBGExecute(TObject *Sender);
	void __fastcall CheckBox1Click(TObject *Sender);
	void __fastcall DisableUIExecute(TObject *Sender);
	void __fastcall EnableUIExecute(TObject *Sender);
private:	// User declarations
public:		// User declarations



        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;


    double globalFemaleMeanMS, globalFemaleMeanRS, globalSexRatio;
    double globalEstimatedNumberMales, globalClutchesSampled;
    double globalNmsIntervals, globalNrsIntervals, globalEstReps, globalBootReps;
    double *globalMaleMS;
    double *globalMaleRS;
    double globalNmaleData;
    double globalEstimationSDMS;
    double globalMSestreps;

    double globalBestStDevMS, globalBestStDevRS, globalBestCorr;

    double globalmeanMS, globalstddevMS, globalmeanRSsim, globalSDwithinMSclass;
    double globalincreaseRSperMate, globalNmales, globalpropClutchesSampled;
    bool globalBigRun;

    double globalResultsRealMeanMS, globalResultsRealMeanRS;
    double globalResultsRealSDMS, globalResultsRealSDRS, globalResultsRealI;
    double globalRestulsRealIs, globalResultsRealBetaSS;

    double globalResultsSampleMeanMS, globalResultsSampleMeanRS;
    double globalResultsSampleSDMS, globalResultsSampleSDRS, globalResultsSampleI;
    double globalRestulsSampleIs, globalResultsSampleBetaSS;

    double globalResultsEstSDMS, globalResultsEstIs;

    double globalResultsEstSDRS, globalResultsEstBG, globalResultsEstBGnz, globalResultsEstI;
    double globalMSstddevmax, globalRSstddevmax, globalNmsintervals, globalRSperMatemax, globalRSperMSintervals;
    double globalCalculatedMaleMSmean, globalCalculatedMaleRSmean;

    double globalcorrMSRS, globalSigmaRS, globalResultscorrMSRS, globalResultsSigmaRS;

	double globalResultsBGprime, globalResultsSmax;

	int iProgress, iMaxProgress;

	AnsiString LogFileName;


double rnZ, bivN1, bivN2;

inline long double NchooseK (double NNN, double KKK);

inline long double NchooseK (double NNN, double KKK)
{
   if (KKK == 0 || KKK == NNN)
      return 1;

   if (KKK < 0 || KKK > NNN)
      return 0;

   long double NKresult;
   long double NKdub1, NKdub2;

   int NKi;
   int iNNN = NNN;

   NKresult = 1;
   for (NKi = 1; NKi < iNNN + 1; NKi++)
   {
     NKdub1 = NKi;
     if (NKi <= KKK)
        NKdub2 = NKdub1;
     else
        NKdub2 = NKdub1 - KKK;

     NKresult = NKresult * (NKdub1/NKdub2);
   }
   return NKresult;
}

// The following code has to do with the random number
// generator.  This is the Marsenne Twister prng.
/* Period parameters */
#define N 624
#define M 397
#define MATRIX_A 0x9908b0df   /* constant vector a */
#define UPPER_MASK 0x80000000 /* most significant w-r bits */
#define LOWER_MASK 0x7fffffff /* least significant r bits */

/* Tempering parameters */
#define TEMPERING_MASK_B 0x9d2c5680
#define TEMPERING_MASK_C 0xefc60000
#define TEMPERING_SHIFT_U(y)  (y >> 11)
#define TEMPERING_SHIFT_S(y)  (y << 7)
#define TEMPERING_SHIFT_T(y)  (y << 15)
#define TEMPERING_SHIFT_L(y)  (y >> 18)

static unsigned long mt[N]; /* the array for the state vector  */
static int mti=N+1; /* mti==N+1 means mt[N] is not initialized */
double Two2the36 = 4294967296.0;

/* initializing the array with a NONZERO seed */
void sgenrand(unsigned long int seed)
{
    /* setting initial seeds to mt[N] using         */
    /* the generator Line 25 of Table 1 in          */
    /* [KNUTH 1981, The Art of Computer Programming */
    /*    Vol. 2 (2nd Ed.), pp102]                  */
    mt[0]= seed & 0xffffffff;
    for (mti=1; mti<N; mti++)
        mt[mti] = (69069 * mt[mti-1]) & 0xffffffff;
}

inline double genrand()
{
    unsigned long y;
    static unsigned long mag01[2]={0x0, MATRIX_A};
    /* mag01[x] = x * MATRIX_A  for x=0,1 */

    if (mti >= N) { /* generate N words at one time */
        int kk;

        if (mti == N+1)   /* if sgenrand() has not been called, */
            sgenrand(4357); /* a default initial seed is used   */

        for (kk=0;kk<N-M;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1];
        }
        for (;kk<N-1;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1];
        }
        y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
        mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1];

        mti = 0;
    }

    y = mt[mti++];
    y ^= TEMPERING_SHIFT_U(y);
    y ^= TEMPERING_SHIFT_S(y) & TEMPERING_MASK_B;
    y ^= TEMPERING_SHIFT_T(y) & TEMPERING_MASK_C;
    y ^= TEMPERING_SHIFT_L(y);

    return ( (double) y / Two2the36 ); /* reals */
     //return y;  /* for integer generation */
     // This should give a range of [0,1); for [0,1]
     // use Two2the36-1.
}


        inline int randnum(int Max)  // returns a value between 0 and Max-1.
        {
           double rnms;
           double dbrnum;
           int irnum;
           rnms = genrand();
           dbrnum = floor(rnms * Max);
           irnum = dbrnum;

           return irnum;
        }

        inline double randnorm(double rnmean, double rnstd)
        {
           double S, v1, v2, X2;
          if (rnZ != 0)
          {
            X2 = rnZ;
            rnZ = 0;
          }
          else
          {
           do {
                v1 = 2.0 * genrand() - 1.0;
                v2 = 2.0 * genrand() - 1.0;
                S = v1 * v1 + v2 * v2;
              } while (S >= 1.0);

           S = sqrt((-2.0 * log(S))/S);
           X2 = v1 * S;
           rnZ = v2 * S;
           }

           return rnmean + X2 * rnstd;
        }

        // this function will generate random numbers from a bivariate
        // normal distribution.  The random numbers will be in the global
        // variables bivN1 and bivN2.  The std deviations of the two distributions
        // are given by sigmaX and sigmaY, and the correlation is rho.
        // These bivariate normal routines are from the GNU free software database
        // (C) 2000 James Theiler and Brian Gough.

        inline void randbivnorm (double sigmaX, double sigmaY, double rho)
        {
           double bivU, bivV, bivR2, bivScale;

           do
           {
             // choose x and y from a uniform square (-1, -1) to (1, 1)

             bivU = 2 * genrand() - 1;
             bivV = 2 * genrand() - 1;

             // see if it is in the unit circle

             bivR2 = bivU * bivU + bivV * bivV;
           }
           while (bivR2 > 1.0 || bivR2 == 0);

           bivScale = sqrt(-2.0 * log(bivR2) / bivR2);

           bivN1 = sigmaX * bivU * bivScale;
           bivN2 = sigmaY * (rho * bivU + sqrt(1 - rho*rho) * bivV) * bivScale;
        } // end of randbivnorm

        inline double bivnormpdf (const double bnX, const double bnY, const double sigmaX,
                const double sigmaY, const double rho)
           {
                double bnU = bnX / sigmaX;
                double bnV = bnY / sigmaY;
                double bnC = 1 - rho*rho;
                double bnP = (1 / (2 * M_PI * sigmaX * sigmaY * sqrt(bnC))) *
                        exp(-(bnU * bnU - 2 * rho * bnU * bnV + bnV * bnV) / (2 * bnC));
                return bnP;
           }  // end of bivnormpdf
//---------------------------------------------------------------------------
#endif
 